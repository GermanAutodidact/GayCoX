package com.example.data

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.scraper.UrlNormalizer
import com.example.worker.DownloadWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class BatchRepository(
  private val context: Context,
  private val queueDao: QueueDao,
  private val sessionDao: SessionDao,
  private val settingsRepository: SettingsRepository
) {
  val allQueueItems: Flow<List<QueueItem>> = queueDao.getAllQueueItems()
  val allSessionsWithImages: Flow<List<SessionWithImages>> = sessionDao.getAllSessionsWithImages()

  fun getImagesForQueue(queueItemId: Long): Flow<List<DownloadedImage>> =
    queueDao.getImagesForQueue(queueItemId)

  suspend fun resetInterruptedItems() = withContext(Dispatchers.IO) {
    queueDao.resetInterruptedItems()
  }

  suspend fun addUrlsToQueue(rawText: String): Int = withContext(Dispatchers.IO) {
    val extracted = UrlNormalizer.extractUrls(rawText)
    if (extracted.isEmpty()) return@withContext 0
    val existing = queueDao.getAllQueueItems().first()
    val existingUrls = existing.map { it.url }.toSet()
    val newItems = extracted.filter { !existingUrls.contains(it) }.map { url ->
      val domain = UrlNormalizer.getDomain(url)
      QueueItem(
        url = url,
        domain = domain,
        title = domain,
        status = QueueStatus.WAITING,
        progress = 0,
        total = 0
      )
    }
    if (newItems.isNotEmpty()) {
      queueDao.insertQueueItems(newItems)
    }
    newItems.size
  }

  suspend fun startAll() = withContext(Dispatchers.IO) {
    val settings = settingsRepository.settingsFlow.first()
    val constraintsBuilder = Constraints.Builder()
      .setRequiredNetworkType(
        if (settings.wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED
      )
    val workRequest = OneTimeWorkRequestBuilder<DownloadWorker>()
      .setConstraints(constraintsBuilder.build())
      .addTag(DownloadWorker.UNIQUE_WORK_NAME)
      .build()
    WorkManager.getInstance(context).enqueueUniqueWork(
      DownloadWorker.UNIQUE_WORK_NAME,
      ExistingWorkPolicy.REPLACE,
      workRequest
    )
  }

  fun cancelDownloads() {
    WorkManager.getInstance(context).cancelUniqueWork(DownloadWorker.UNIQUE_WORK_NAME)
  }

  suspend fun deleteQueueItem(id: Long) = withContext(Dispatchers.IO) {
    queueDao.deleteQueueItemById(id)
  }

  suspend fun deleteCompletedItems() = withContext(Dispatchers.IO) {
    queueDao.deleteCompletedItems()
  }

  suspend fun deleteSession(sessionId: Long) = withContext(Dispatchers.IO) {
    sessionDao.deleteSessionById(sessionId)
  }

  suspend fun clearAllSessions() = withContext(Dispatchers.IO) {
    sessionDao.clearAllSessions()
  }

  suspend fun clearAll() = withContext(Dispatchers.IO) {
    cancelDownloads()
    queueDao.clearAll()
  }

  suspend fun retryItem(id: Long) = withContext(Dispatchers.IO) {
    queueDao.retryErrorItem(id)
    startAll()
  }

  suspend fun retryAllErrors() = withContext(Dispatchers.IO) {
    queueDao.retryAllErrorItems()
    startAll()
  }

  /**
   * User hat in der Vorschau ausgewählt → speichere nur Fullsize-URLs
   * und starte Phase-2-Download.
   */
  suspend fun confirmSelectionAndDownload(itemId: Long, selectedFullUrls: List<String>) =
    withContext(Dispatchers.IO) {
      if (selectedFullUrls.isEmpty()) return@withContext
      val json = org.json.JSONArray(selectedFullUrls).toString()
      queueDao.updateCandidateUrls(itemId, json)
      queueDao.updateStatus(itemId, QueueStatus.READY_TO_DOWNLOAD, null)
      startAll()
    }
}
