package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.example.ui.theme.HeartRed
import com.example.ui.theme.MattePastelPink

/**
 * Decorative data point for a scattered heart in the background.
 */
private data class ScatteredHeart(
  val xRatio: Float,
  val yRatio: Float,
  val sizeDp: Float,
  val rotation: Float,
  val alpha: Float,
  val color: Color = HeartRed
)

// Carefully distributed, playful scatter coordinates across the screen
private val BACKGROUND_HEARTS = listOf(
  ScatteredHeart(0.08f, 0.05f, 22f, -15f, 0.16f),
  ScatteredHeart(0.88f, 0.07f, 28f, 20f, 0.14f),
  ScatteredHeart(0.48f, 0.12f, 16f, -10f, 0.10f),
  ScatteredHeart(0.92f, 0.22f, 20f, 12f, 0.15f),
  ScatteredHeart(0.06f, 0.28f, 26f, -25f, 0.13f),
  ScatteredHeart(0.78f, 0.36f, 18f, 8f, 0.11f),
  ScatteredHeart(0.18f, 0.44f, 22f, 16f, 0.12f),
  ScatteredHeart(0.86f, 0.52f, 24f, -18f, 0.14f),
  ScatteredHeart(0.12f, 0.60f, 20f, 14f, 0.11f),
  ScatteredHeart(0.72f, 0.68f, 16f, -12f, 0.13f),
  ScatteredHeart(0.90f, 0.76f, 26f, 22f, 0.15f),
  ScatteredHeart(0.14f, 0.82f, 24f, -20f, 0.14f),
  ScatteredHeart(0.52f, 0.88f, 18f, 10f, 0.12f),
  ScatteredHeart(0.84f, 0.94f, 22f, -15f, 0.13f),
  ScatteredHeart(0.08f, 0.96f, 20f, 18f, 0.15f)
)

/**
 * Draws a bezier heart centered at (centerX, centerY) with specified width and height.
 */
private fun DrawScope.drawHeart(
  centerX: Float,
  centerY: Float,
  size: Float,
  color: Color,
  rotationDegrees: Float
) {
  val path = Path().apply {
    val width = size
    val height = size * 0.95f
    val top = centerY - height / 2f
    val left = centerX - width / 2f
    val right = left + width
    val bottom = top + height

    moveTo(centerX, top + height * 0.25f)
    cubicTo(
      centerX, top,
      left, top,
      left, top + height * 0.35f
    )
    cubicTo(
      left, top + height * 0.65f,
      centerX, bottom,
      centerX, bottom
    )
    cubicTo(
      centerX, bottom,
      right, top + height * 0.65f,
      right, top + height * 0.35f
    )
    cubicTo(
      right, top,
      centerX, top,
      centerX, top + height * 0.25f
    )
    close()
  }

  rotate(degrees = rotationDegrees, pivot = Offset(centerX, centerY)) {
    drawPath(path = path, color = color)
  }
}

/**
 * Matte Soft Pastel Pink background container adorned with delicate,
 * scattered red heart patterns and subtle glowing accents.
 */
@Composable
fun MatteHeartBackground(
  modifier: Modifier = Modifier,
  content: @Composable () -> Unit
) {
  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MattePastelPink)
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height

      // Subtle warm blush gradients melting into the pastel pink at corners
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(Color(0x22E53935), Color(0x00E53935)),
          center = Offset(w * 0.9f, h * 0.1f),
          radius = w * 0.6f
        ),
        radius = w * 0.6f,
        center = Offset(w * 0.9f, h * 0.1f)
      )

      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(Color(0x18D81B60), Color(0x00D81B60)),
          center = Offset(w * 0.1f, h * 0.85f),
          radius = w * 0.55f
        ),
        radius = w * 0.55f,
        center = Offset(w * 0.1f, h * 0.85f)
      )

      // Draw playful scattered decorative hearts
      for (heart in BACKGROUND_HEARTS) {
        val pxX = heart.xRatio * w
        val pxY = heart.yRatio * h
        val pxSize = heart.sizeDp.dp.toPx()
        drawHeart(
          centerX = pxX,
          centerY = pxY,
          size = pxSize,
          color = heart.color.copy(alpha = heart.alpha),
          rotationDegrees = heart.rotation
        )
      }
    }
    content()
  }
}
