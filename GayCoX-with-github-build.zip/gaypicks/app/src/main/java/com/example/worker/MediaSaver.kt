package com.example.worker

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.security.MessageDigest

data class SavedImageInfo(
  val uri: Uri,
  val fileName: String,
  val size: Long,
  val width: Int,
  val height: Int,
  val mimeType: String
)

data class ProcessedImageResult(
  val bytes: ByteArray,
  val width: Int,
  val height: Int,
  val mimeType: String = "image/jpeg",
  val ext: String = "jpg"
)

object MediaSaver {
  fun sanitizeFolderName(name: String): String {
    val sanitized = name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
      .replace(Regex("_+"), "_")
      .trim('_')
    return if (sanitized.isBlank()) "Downloads" else sanitized.take(60)
  }

  fun computeUrlHash(url: String): String {
    val digest = MessageDigest.getInstance("SHA-256")
    val hashBytes = digest.digest(url.toByteArray(Charsets.UTF_8))
    return hashBytes.take(6).joinToString("") { "%02x".format(it) }
  }

  fun determineMimeAndExt(bytes: ByteArray, urlHint: String): Pair<String, String> {
    if (bytes.size >= 3 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() && bytes[2] == 0xFF.toByte()) {
      return Pair("image/jpeg", "jpg")
    }
    if (bytes.size >= 4 && bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() && bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte()) {
      return Pair("image/png", "png")
    }
    if (bytes.size >= 4 && bytes[0] == 0x47.toByte() && bytes[1] == 0x49.toByte() && bytes[2] == 0x46.toByte() && bytes[3] == 0x38.toByte()) {
      return Pair("image/gif", "gif")
    }
    if (bytes.size >= 12 &&
      bytes[0] == 0x52.toByte() && bytes[1] == 0x49.toByte() && bytes[2] == 0x46.toByte() && bytes[3] == 0x46.toByte() &&
      bytes[8] == 0x57.toByte() && bytes[9] == 0x45.toByte() && bytes[10] == 0x42.toByte() && bytes[11] == 0x50.toByte()
    ) {
      return Pair("image/webp", "webp")
    }
    val clean = urlHint.substringBefore('?').substringBefore('#')
    val ext = clean.substringAfterLast('.', "jpg").lowercase()
    val mime = when (ext) {
      "png" -> "image/png"
      "gif" -> "image/gif"
      "webp" -> "image/webp"
      else -> "image/jpeg"
    }
    return Pair(mime, ext)
  }

  fun validateImage(
    bytes: ByteArray,
    minSizeKb: Int,
    minDimensionPx: Int
  ): Pair<Int, Int>? {
    if (bytes.size < minSizeKb * 1024) {
      return null
    }
    val options = BitmapFactory.Options().apply {
      inJustDecodeBounds = true
    }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
    val width = options.outWidth
    val height = options.outHeight
    if (width < minDimensionPx || height < minDimensionPx) {
      return null
    }
    return Pair(width, height)
  }

  /**
   * Converts any image (PNG, WebP, GIF, JPEG) to JPG format, and if the file size
   * exceeds maxSizeKb (default 300 KB), dynamically downscales and compresses it
   * until it strictly fits under maxSizeKb.
   */
  fun processAndConvertToJpg(
    rawBytes: ByteArray,
    maxSizeKb: Int = 300
  ): ProcessedImageResult? {
    val maxSizeBytes = maxSizeKb * 1024
    val options = BitmapFactory.Options().apply {
      inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    var currentBitmap = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, options) ?: return null
    if (currentBitmap.hasAlpha()) {
      val nonAlphaBitmap = Bitmap.createBitmap(currentBitmap.width, currentBitmap.height, Bitmap.Config.ARGB_8888)
      val canvas = Canvas(nonAlphaBitmap)
      canvas.drawColor(android.graphics.Color.WHITE)
      canvas.drawBitmap(currentBitmap, 0f, 0f, null)
      currentBitmap.recycle()
      currentBitmap = nonAlphaBitmap
    }
    try {
      var width = currentBitmap.width
      var height = currentBitmap.height
      var quality = 90
      var outputStream = ByteArrayOutputStream()
      currentBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
      var resultBytes = outputStream.toByteArray()
      if (resultBytes.size <= maxSizeBytes) {
        return ProcessedImageResult(
          bytes = resultBytes,
          width = width,
          height = height
        )
      }
      while (resultBytes.size > maxSizeBytes && quality > 45) {
        quality -= 10
        outputStream = ByteArrayOutputStream()
        currentBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        resultBytes = outputStream.toByteArray()
      }
      while (resultBytes.size > maxSizeBytes && width > 300 && height > 300) {
        val scale = 0.8f
        val newWidth = (width * scale).toInt().coerceAtLeast(200)
        val newHeight = (height * scale).toInt().coerceAtLeast(200)
        val scaledBitmap = Bitmap.createScaledBitmap(currentBitmap, newWidth, newHeight, true)
        if (currentBitmap != scaledBitmap) {
          currentBitmap.recycle()
        }
        currentBitmap = scaledBitmap
        width = newWidth
        height = newHeight
        quality = 80
        outputStream = ByteArrayOutputStream()
        currentBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        resultBytes = outputStream.toByteArray()
        while (resultBytes.size > maxSizeBytes && quality > 40) {
          quality -= 10
          outputStream = ByteArrayOutputStream()
          currentBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
          resultBytes = outputStream.toByteArray()
        }
      }
      return ProcessedImageResult(
        bytes = resultBytes,
        width = width,
        height = height
      )
    } finally {
      currentBitmap.recycle()
    }
  }

  fun saveToMediaStore(
    context: Context,
    bytes: ByteArray,
    folderName: String,
    fileNameBase: String,
    mimeType: String,
    ext: String,
    width: Int,
    height: Int
  ): SavedImageInfo? {
    val resolver: ContentResolver = context.contentResolver
    val sanitizedFolder = sanitizeFolderName(folderName)
    val relativePath = "Pictures/GayCoX/$sanitizedFolder/"
    val finalFileName = "${fileNameBase}.$ext"
    val contentValues = ContentValues().apply {
      put(MediaStore.Images.Media.DISPLAY_NAME, finalFileName)
      put(MediaStore.Images.Media.MIME_TYPE, mimeType)
      put(MediaStore.Images.Media.RELATIVE_PATH, relativePath)
      put(MediaStore.Images.Media.IS_PENDING, 1)
      put(MediaStore.Images.Media.WIDTH, width)
      put(MediaStore.Images.Media.HEIGHT, height)
    }
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
      ?: return null
    return try {
      resolver.openOutputStream(uri)?.use { os ->
        os.write(bytes)
        os.flush()
      }
      contentValues.clear()
      contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
      resolver.update(uri, contentValues, null, null)
      SavedImageInfo(
        uri = uri,
        fileName = finalFileName,
        size = bytes.size.toLong(),
        width = width,
        height = height,
        mimeType = mimeType
      )
    } catch (e: Exception) {
      resolver.delete(uri, null, null)
      null
    }
  }
}
