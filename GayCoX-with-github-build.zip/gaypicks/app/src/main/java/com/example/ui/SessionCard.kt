package com.example.ui

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.SessionImage
import com.example.data.SessionWithImages
import com.example.ui.theme.BerryPrimary
import com.example.ui.theme.HeartRed
import com.example.ui.theme.MatteBorder
import com.example.ui.theme.MatteBorderSubtle
import com.example.ui.theme.MatteCardBg
import com.example.ui.theme.MattePinkSurface
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.TextDeepCharcoal
import com.example.ui.theme.TextMutedPlum
import com.example.ui.theme.TextPlumMedium
import com.example.ui.theme.TextWhite
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SessionCard(
  sessionWithImages: SessionWithImages,
  onDeleteSession: () -> Unit,
  onImageClick: (SessionImage) -> Unit,
  modifier: Modifier = Modifier
) {
  val session = sessionWithImages.session
  val images = sessionWithImages.images
  var isExpanded by remember { mutableStateOf(false) }

  val formattedDate = remember(session.completedAt) {
    SimpleDateFormat("dd. MMM yyyy, HH:mm", Locale.getDefault()).format(Date(session.completedAt))
  }
  val formattedSize = remember(session.totalBytes) {
    formatFileSize(session.totalBytes)
  }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(18.dp))
      .clickable { isExpanded = !isExpanded }
      .testTag("session_card_${session.id}"),
    shape = RoundedCornerShape(18.dp),
    border = BorderStroke(1.dp, MatteBorder),
    colors = CardDefaults.cardColors(
      containerColor = MatteCardBg
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      // Header: Domain, Title, Badges
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MattePinkSurface,
            border = BorderStroke(1.dp, MatteBorder),
            modifier = Modifier.size(38.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.Language,
                contentDescription = null,
                tint = BerryPrimary,
                modifier = Modifier.size(20.dp)
              )
            }
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = session.title.ifBlank { session.domain.ifBlank { "Download-Sitzung" } },
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = TextDeepCharcoal,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Text(
              text = session.domain,
              style = MaterialTheme.typography.bodySmall,
              color = TextPlumMedium,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }
        }
        Spacer(modifier = Modifier.width(8.dp))

        // Image Count Badge
        Surface(
          shape = CircleShape,
          color = Color(0x2016A34A),
          border = BorderStroke(1.dp, StatusSuccess.copy(alpha = 0.5f))
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.PhotoLibrary,
              contentDescription = null,
              tint = StatusSuccess,
              modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "${session.imageCount} Bilder",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = StatusSuccess
            )
          }
        }

        val rotation by animateFloatAsState(
          targetValue = if (isExpanded) 180f else 0f,
          label = "expand_rotation"
        )
        Icon(
          imageVector = Icons.Default.KeyboardArrowDown,
          contentDescription = "Aufklappen",
          modifier = Modifier
            .size(26.dp)
            .rotate(rotation)
            .padding(start = 6.dp),
          tint = TextPlumMedium
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Metadata Bar: Date, Size, Storage Location
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = formattedDate,
            style = MaterialTheme.typography.labelSmall,
            color = TextMutedPlum
          )
          if (session.folderName.isNotBlank()) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(top = 2.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Folder,
                contentDescription = null,
                tint = HeartRed,
                modifier = Modifier.size(12.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "Pictures/GayCoX/${session.folderName}",
                style = MaterialTheme.typography.labelSmall,
                color = TextPlumMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
          }
        }

        if (session.totalBytes > 0) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = MattePinkSurface,
            border = BorderStroke(1.dp, MatteBorderSubtle)
          ) {
            Text(
              text = formattedSize,
              fontFamily = FontFamily.Monospace,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = TextDeepCharcoal,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }
        }
      }

      // Compact Preview Strip when closed
      if (!isExpanded && images.isNotEmpty()) {
        Spacer(modifier = Modifier.height(12.dp))
        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          items(images.take(6), key = { it.id }) { image ->
            AsyncImage(
              model = image.localUri,
              contentDescription = image.fileName,
              contentScale = ContentScale.Crop,
              modifier = Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, MatteBorder, RoundedCornerShape(8.dp))
                .background(MattePinkSurface)
                .clickable { onImageClick(image) }
            )
          }
          if (images.size > 6) {
            item {
              Box(
                modifier = Modifier
                  .size(46.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(MattePinkSurface)
                  .border(1.dp, MatteBorder, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = "+${images.size - 6}",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = HeartRed
                )
              }
            }
          }
        }
      }

      // Expanded View: Full Grid & Actions
      AnimatedVisibility(visible = isExpanded) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 14.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Gespeicherte Bilder (${images.size})",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = TextDeepCharcoal
            )

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              val context = LocalContext.current
              IconButton(
                onClick = {
                  val intent = Intent(Intent.ACTION_VIEW).apply {
                    type = "image/*"
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                  }
                  try {
                    context.startActivity(intent)
                  } catch (_: Exception) {}
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Share,
                  contentDescription = "In Galerie öffnen",
                  tint = BerryPrimary,
                  modifier = Modifier.size(18.dp)
                )
              }

              IconButton(
                onClick = onDeleteSession,
                modifier = Modifier.size(32.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.DeleteOutline,
                  contentDescription = "Sitzung löschen",
                  tint = StatusError,
                  modifier = Modifier.size(18.dp)
                )
              }
            }
          }

          LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 75.dp),
            contentPadding = PaddingValues(2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(max = 240.dp)
          ) {
            items(images, key = { it.id }) { image ->
              AsyncImage(
                model = image.localUri,
                contentDescription = image.fileName,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                  .aspectRatio(1f)
                  .clip(RoundedCornerShape(12.dp))
                  .border(1.dp, MatteBorder, RoundedCornerShape(12.dp))
                  .background(MattePinkSurface)
                  .clickable { onImageClick(image) }
              )
            }
          }
        }
      }
    }
  }
}

fun formatFileSize(bytes: Long): String {
  if (bytes <= 0) return "0 B"
  val kb = bytes / 1024.0
  val mb = kb / 1024.0
  val gb = mb / 1024.0
  return when {
    gb >= 1.0 -> String.format(Locale.US, "%.1f GB", gb)
    mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
    kb >= 1.0 -> String.format(Locale.US, "%.1f KB", kb)
    else -> "$bytes B"
  }
}
