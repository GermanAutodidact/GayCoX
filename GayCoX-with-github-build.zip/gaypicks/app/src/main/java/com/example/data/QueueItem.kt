package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class QueueStatus {
  /** Wartet auf Phase-1-Scan */
  WAITING,
  SCANNING,
  /** Phase 1 fertig – Kandidaten bereit, User muss in der Vorschau auswählen */
  AWAITING_SELECTION,
  /** User hat Auswahl bestätigt – bereit für Phase-2-Download */
  READY_TO_DOWNLOAD,
  DOWNLOADING,
  COMPLETED,
  ERROR
}

@Entity(tableName = "queue_items")
data class QueueItem(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val url: String,
  val domain: String = "",
  val title: String = "",
  val status: QueueStatus = QueueStatus.WAITING,
  val progress: Int = 0,
  val total: Int = 0,
  val errorMessage: String? = null,
  val logReport: String = "",
  val candidateUrlsJson: String = "",
  val createdAt: Long = System.currentTimeMillis()
)
