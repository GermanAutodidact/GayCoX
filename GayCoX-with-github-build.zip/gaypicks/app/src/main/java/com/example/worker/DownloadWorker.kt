package com.example.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.MainActivity
import com.example.R
import com.example.data.AppDatabase
import com.example.data.AppSettings
import com.example.data.DownloadSession
import com.example.data.DownloadedImage
import com.example.data.QueueItem
import com.example.data.QueueStatus
import com.example.data.SessionImage
import com.example.data.SettingsRepository
import com.example.scraper.UrlNormalizer
import com.example.scraper.WebViewScraper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class DownloadWorker(
  private val appContext: Context,
  params: WorkerParameters
) : CoroutineWorker(appContext, params) {

  companion object {
    const val UNIQUE_WORK_NAME = "GayCoXDownloadWork"
    const val NOTIFICATION_CHANNEL_ID = "gaycox_download_channel"
    const val NOTIFICATION_ID = 1001
    const val ACTION_CANCEL_DOWNLOAD = "com.aistudio.gaycox.CANCEL_DOWNLOAD"
    private const val DESKTOP_UA =
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
  }

  private val notificationManager =
    appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  private val database = AppDatabase.getInstance(appContext)
  private val queueDao = database.queueDao()
  private val sessionDao = database.sessionDao()
  private val settingsRepository = SettingsRepository(appContext)

  private val okHttpClient = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(30, TimeUnit.SECONDS)
    .followRedirects(true)
    .followSslRedirects(true)
    .build()

  private val scraper = WebViewScraper(appContext, okHttpClient)

  override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
    createNotificationChannel()
    setForeground(createForegroundInfo(0, 0, "Initialisiere Downloads …", false))
    val settings = settingsRepository.settingsFlow.first()

    try {
      while (true) {
        if (isStopped) break
        // Zuerst Phase-2-Downloads (User hat Auswahl bestätigt)
        val readyItems = queueDao.getReadyToDownloadItems()
        for (item in readyItems) {
          if (isStopped) break
          processDownloadPhase(item, settings)
        }
        // Dann Phase-1-Scans
        val waitingItems = queueDao.getWaitingQueueItems()
        if (waitingItems.isEmpty() && readyItems.isEmpty()) {
          break
        }
        for (item in waitingItems) {
          if (isStopped) break
          processQueueItem(item, settings)
        }
        // Falls während des Scans neue READY_TO_DOWNLOAD entstanden (Direktbilder),
        // nächste Schleife greift sie ab.
        if (waitingItems.isEmpty()) break
      }
      Result.success()
    } catch (e: CancellationException) {
      queueDao.resetInterruptedItems()
      Result.failure()
    } catch (e: Exception) {
      queueDao.resetInterruptedItems()
      Result.failure()
    }
  }

  /**
   * Phase 2 für Items im Status READY_TO_DOWNLOAD:
   * candidateUrlsJson enthält entweder Fullsize-URLs (String-Array)
   * oder das t/f-Format – wir nehmen immer die Fullsize-URLs.
   */
  private suspend fun processDownloadPhase(item: QueueItem, settings: AppSettings) {
    val log = StringBuilder(item.logReport)
    fun appendLog(msg: String) {
      val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
      synchronized(log) { log.append("[$time] $msg\n") }
    }
    val selectedUrls = parseFullUrlsFromCandidatesJson(item.candidateUrlsJson)
    if (selectedUrls.isEmpty()) {
      appendLog("✖ READY_TO_DOWNLOAD ohne gültige URLs")
      queueDao.updateStatusWithLog(item.id, QueueStatus.ERROR, "Keine Download-URLs", log.toString())
      return
    }
    downloadSelectedImages(
      item = item,
      settings = settings,
      selectedFullUrls = selectedUrls,
      cookies = "",
      log = log,
      appendLog = ::appendLog
    )
  }

  private fun parseFullUrlsFromCandidatesJson(json: String): List<String> {
    if (json.isBlank()) return emptyList()
    return try {
      val arr = JSONArray(json)
      val result = mutableListOf<String>()
      for (i in 0 until arr.length()) {
        val el = arr.opt(i)
        when (el) {
          is org.json.JSONObject -> {
            val full = el.optString("f").ifBlank { el.optString("full") }
            if (full.isNotBlank()) result.add(full)
          }
          is String -> if (el.isNotBlank()) result.add(el)
          else -> {
            val s = arr.optString(i)
            if (s.isNotBlank() && !s.startsWith("{")) result.add(s)
          }
        }
      }
      result.distinct()
    } catch (_: Exception) {
      emptyList()
    }
  }

  private suspend fun processQueueItem(item: QueueItem, settings: AppSettings) {
    val itemId = item.id
    val log = StringBuilder()

    fun appendLog(msg: String) {
      val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
      val entry = "[$time] $msg\n"
      synchronized(log) {
        log.append(entry)
      }
    }

    appendLog("▶ Starte Scan für URL: ${item.url}")
    appendLog("⚙ Einstellungen: Mindestgröße ≥ ${settings.minSizeKb} KB, Mindestauflösung ≥ ${settings.minDimensionPx}x${settings.minDimensionPx} PX, Zielformat: JPG (max. ${settings.maxSizeKb} KB)")

    queueDao.updateStatusWithLog(itemId, QueueStatus.SCANNING, null, log.toString())
    setForeground(
      createForegroundInfo(
        progress = 0,
        max = 0,
        statusText = "Scanne ${item.url}",
        indeterminate = true
      )
    )

    val isDirectImage = UrlNormalizer.isSupportedImage(item.url)
    val scrapeResult = if (isDirectImage) {
      appendLog("✓ Direktes Bild erkannt: ${item.url}")
      com.example.scraper.ScrapeResult(
        title = UrlNormalizer.getDomain(item.url).ifBlank { "Direktes Bild" },
        domain = UrlNormalizer.getDomain(item.url),
        imageUrls = listOf(item.url),
        candidates = listOf(
          com.example.scraper.ImageCandidate(thumbnailUrl = item.url, fullUrl = item.url)
        ),
        cookies = ""
      )
    } else {
      try {
        scraper.scrapeUrl(item.url, settings) { pagesScanned, linksFound, currentSubpage ->
          appendLog("🔍 Phase 1 (Crawl): Seite $pagesScanned gescannt, bisher $linksFound Bild-Links gesammelt ($currentSubpage)")
          queueDao.updateProgressWithLog(itemId, pagesScanned, linksFound, log.toString())
          setForeground(
            createForegroundInfo(
              progress = 0,
              max = 0,
              statusText = "Phase 1 (Crawl): $pagesScanned Seiten • $linksFound Bild-Links gesammelt",
              indeterminate = true
            )
          )
        }
      } catch (e: Exception) {
        appendLog("✖ Scraping fehlgeschlagen: ${e.message}")
        queueDao.updateStatusWithLog(itemId, QueueStatus.ERROR, e.message ?: "Scraping fehlgeschlagen", log.toString())
        return
      }
    }

    if (scrapeResult.imageUrls.isEmpty() && scrapeResult.candidates.isEmpty()) {
      appendLog("✖ Keine Bilder im Quelltext oder DOM der Seite gefunden.")
      queueDao.updateStatusWithLog(itemId, QueueStatus.ERROR, "Keine Bilder gefunden", log.toString())
      return
    }

    // Kandidaten als JSON speichern: [{"t":"thumbUrl","f":"fullUrl"}, ...]
    // Vorschau zeigt Thumbnails, Download nutzt Fullsize
    val pairs = if (scrapeResult.candidates.isNotEmpty()) {
      scrapeResult.candidates
    } else {
      scrapeResult.imageUrls.map {
        com.example.scraper.ImageCandidate(thumbnailUrl = it, fullUrl = it)
      }
    }
    val candidatesJson = JSONArray().apply {
      for (c in pairs) {
        put(org.json.JSONObject().apply {
          put("t", c.thumbnailUrl)
          put("f", c.fullUrl)
        })
      }
    }.toString()
    queueDao.updateCandidateUrls(itemId, candidatesJson)

    val pageTitle = scrapeResult.title.ifBlank { scrapeResult.domain }
    queueDao.updateMetadata(itemId, pageTitle, scrapeResult.domain)
    queueDao.updateProgressWithLog(itemId, 0, pairs.size, log.toString())

    // Direkte Einzelbilder → sofort downloaden, Galerien → Vorschau-Auswahl erzwingen
    if (isDirectImage) {
      appendLog("✓ Direktes Bild – starte Download ohne Vorschau.")
      queueDao.updateStatusWithLog(itemId, QueueStatus.READY_TO_DOWNLOAD, null, log.toString())
      downloadSelectedImages(
        item = item.copy(title = pageTitle, domain = scrapeResult.domain, candidateUrlsJson = candidatesJson),
        settings = settings,
        selectedFullUrls = listOf(item.url),
        cookies = scrapeResult.cookies,
        log = log,
        appendLog = ::appendLog
      )
      return
    }

    appendLog("✓ Phase 1 abgeschlossen: ${pairs.size} Bild-Kandidaten gefunden.")
    appendLog("⏸ Warte auf Vorschau-Auswahl – bitte Bilder in der App prüfen und bestätigen.")
    queueDao.updateStatusWithLog(itemId, QueueStatus.AWAITING_SELECTION, null, log.toString())
    setForeground(
      createForegroundInfo(
        progress = pairs.size,
        max = pairs.size,
        statusText = "${pairs.size} Bilder bereit – bitte in der App auswählen",
        indeterminate = false
      )
    )
  }

  /**
   * Phase 2: Lädt nur die vom User ausgewählten Fullsize-URLs herunter.
   */
  private suspend fun downloadSelectedImages(
    item: QueueItem,
    settings: AppSettings,
    selectedFullUrls: List<String>,
    cookies: String,
    log: StringBuilder,
    appendLog: (String) -> Unit
  ) {
    val itemId = item.id
    val pageTitle = item.title.ifBlank { item.domain }
    val totalCount = selectedFullUrls.size
    if (totalCount == 0) {
      appendLog("✖ Keine Bilder ausgewählt.")
      queueDao.updateStatusWithLog(itemId, QueueStatus.ERROR, "Keine Auswahl", log.toString())
      return
    }

    appendLog("⬇ Phase 2: Starte Download von $totalCount ausgewählten Bild(ern) …")
    queueDao.updateProgressWithLog(itemId, 0, totalCount, log.toString())
    queueDao.updateStatusWithLog(itemId, QueueStatus.DOWNLOADING, null, log.toString())

    val completedCount = AtomicInteger(0)
    val skippedSmallCount = AtomicInteger(0)
    val skippedDimensionCount = AtomicInteger(0)
    val httpErrorCount = AtomicInteger(0)
    val successCount = AtomicInteger(0)
    val semaphore = Semaphore(settings.concurrency.coerceIn(1, 8))
    val seenUrlHashes = mutableSetOf<String>()

    coroutineScope {
      val deferredDownloads = selectedFullUrls.mapIndexed { index, imageUrl ->
        async {
          if (isStopped) return@async
          val urlHash = MediaSaver.computeUrlHash(imageUrl)
          synchronized(seenUrlHashes) {
            if (seenUrlHashes.contains(urlHash)) return@async
            seenUrlHashes.add(urlHash)
          }

          semaphore.withPermit {
            if (isStopped) return@withPermit
            downloadSingleImage(
              queueItemId = itemId,
              imageUrl = imageUrl,
              referer = item.url,
              cookies = cookies,
              folderName = pageTitle,
              index = index + 1,
              settings = settings,
              isDirect = false,
              skippedSmallCount = skippedSmallCount,
              skippedDimensionCount = skippedDimensionCount,
              httpErrorCount = httpErrorCount,
              successCount = successCount,
              appendLog = appendLog
            )

            val currentDone = completedCount.incrementAndGet()
            queueDao.updateProgressWithLog(itemId, currentDone, totalCount, log.toString())
            setForeground(
              createForegroundInfo(
                progress = currentDone,
                max = totalCount,
                statusText = "$pageTitle: $currentDone/$totalCount",
                indeterminate = false
              )
            )
          }
        }
      }
      deferredDownloads.awaitAll()
    }

    if (!isStopped) {
      val finalSaved = queueDao.getImagesForQueueSync(itemId)
      if (finalSaved.isEmpty()) {
        appendLog("\n⚠ SCAN-ABSCHLUSS: 0 von $totalCount Bildern gespeichert.")
        appendLog("ℹ Diagnose:")
        appendLog("   • ${skippedSmallCount.get()} Bilder waren kleiner als ${settings.minSizeKb} KB")
        appendLog("   • ${skippedDimensionCount.get()} Bilder hatten Maße unter ${settings.minDimensionPx} PX")
        appendLog("   • ${httpErrorCount.get()} Bilder schlugen mit HTTP-Serverfehlern fehl")
        appendLog("\n💡 TIPPS ZUR BEHEBUNG:")
        appendLog("   1. Tippe auf den Button 'Vorschau' auf dieser Karte, um alle $totalCount gefundenen Bilder zu prüfen und direkt auszuwählen!")
        appendLog("   2. Oder stelle in den Einstellungen 'Mindestdateigröße' auf 0 KB, damit auch kleinere Originalbilder akzeptiert werden.")

        val errorSummary = if (skippedSmallCount.get() > 0) {
          "$totalCount Bilder gefunden, aber alle < ${settings.minSizeKb} KB (Tippe auf 'Vorschau' oder 'Log')"
        } else {
          "Bilder entsprachen nicht den Filtern ($totalCount geprüft)"
        }
        queueDao.updateStatusWithLog(itemId, QueueStatus.ERROR, errorSummary, log.toString())
      } else {
        appendLog("\n🎉 ERFOLG: ${finalSaved.size} von $totalCount Bildern erfolgreich als JPG gespeichert!")
        queueDao.updateStatusWithLog(itemId, QueueStatus.COMPLETED, null, log.toString())

        try {
          val totalBytes = finalSaved.sumOf { it.fileSize }
          val session = DownloadSession(
            title = pageTitle,
            sourceUrl = item.url,
            domain = item.domain,
            imageCount = finalSaved.size,
            totalBytes = totalBytes,
            folderName = pageTitle,
            completedAt = System.currentTimeMillis()
          )
          val sessionId = sessionDao.insertSession(session)
          val sessionImages = finalSaved.map { saved ->
            SessionImage(
              sessionId = sessionId,
              originalUrl = saved.originalUrl,
              localUri = saved.localUri,
              fileName = saved.fileName,
              fileSize = saved.fileSize,
              width = saved.width,
              height = saved.height
            )
          }
          sessionDao.insertSessionImages(sessionImages)
        } catch (_: Exception) {}
      }
    }
  }

  private suspend fun downloadSingleImage(
    queueItemId: Long,
    imageUrl: String,
    referer: String,
    cookies: String,
    folderName: String,
    index: Int,
    settings: AppSettings,
    isDirect: Boolean = false,
    skippedSmallCount: AtomicInteger,
    skippedDimensionCount: AtomicInteger,
    httpErrorCount: AtomicInteger,
    successCount: AtomicInteger,
    appendLog: (String) -> Unit
  ): Boolean {
    var attempt = 0
    var delayMs = 500L
    val actualUrl = UrlNormalizer.tryUpgradeThumbnail(imageUrl, okHttpClient, referer)

    while (attempt < 3) {
      attempt++
      try {
        val requestBuilder = Request.Builder()
          .url(actualUrl)
          .header("User-Agent", DESKTOP_UA)
          .header("Referer", referer)
          .header("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8")
        if (cookies.isNotBlank()) {
          requestBuilder.header("Cookie", cookies)
        }
        val response = okHttpClient.newCall(requestBuilder.build()).execute()
        if (!response.isSuccessful) {
          val code = response.code
          val msg = response.message
          response.close()
          appendLog("  Bild #$index: HTTP $code ($msg) bei $imageUrl")
          httpErrorCount.incrementAndGet()
          if (attempt < 3) {
            delay(delayMs)
            delayMs *= 2
            continue
          }
          return false
        }
        val bytes = response.body?.bytes()
        response.close()
        if (bytes == null || bytes.isEmpty()) {
          appendLog("  Bild #$index: 0 Bytes empfangen bei $imageUrl")
          return false
        }

        val effectiveMinSize = if (isDirect) 0 else settings.minSizeKb
        val effectiveMinDim = if (isDirect) 0 else settings.minDimensionPx

        val sizeKb = bytes.size / 1024
        if (sizeKb < effectiveMinSize) {
          skippedSmallCount.incrementAndGet()
          appendLog("  Bild #$index: $sizeKb KB < $effectiveMinSize KB Mindestgrenze übersprungen ($imageUrl)")
          return false
        }

        val dimensions = MediaSaver.validateImage(
          bytes = bytes,
          minSizeKb = effectiveMinSize,
          minDimensionPx = effectiveMinDim
        )
        if (dimensions == null) {
          skippedDimensionCount.incrementAndGet()
          appendLog("  Bild #$index: Maße < ${effectiveMinDim}x${effectiveMinDim} PX oder ungültiges Bildformat -> übersprungen ($imageUrl)")
          return false
        }

        val processed = MediaSaver.processAndConvertToJpg(
          rawBytes = bytes,
          maxSizeKb = settings.maxSizeKb
        )
        if (processed == null) {
          appendLog("  Bild #$index: Konvertierung in JPG fehlgeschlagen -> übersprungen")
          return false
        }

        val hash = MediaSaver.computeUrlHash(imageUrl)
        val fileNameBase = "img_${index}_${hash}"
        val savedInfo = MediaSaver.saveToMediaStore(
          context = appContext,
          bytes = processed.bytes,
          folderName = folderName,
          fileNameBase = fileNameBase,
          mimeType = processed.mimeType,
          ext = processed.ext,
          width = processed.width,
          height = processed.height
        )
        if (savedInfo == null) {
          appendLog("  Bild #$index: Fehler beim Speichern in MediaStore")
          return false
        }

        val entity = DownloadedImage(
          queueItemId = queueItemId,
          originalUrl = actualUrl,
          localUri = savedInfo.uri.toString(),
          fileName = savedInfo.fileName,
          fileSize = savedInfo.size,
          width = savedInfo.width,
          height = savedInfo.height
        )
        queueDao.insertImage(entity)
        successCount.incrementAndGet()
        appendLog("  Bild #$index: Gespeichert als JPG (${savedInfo.size / 1024} KB, ${savedInfo.width}x${savedInfo.height} PX)")
        return true
      } catch (e: IOException) {
        if (attempt < 3) {
          delay(delayMs)
          delayMs *= 2
        } else {
          appendLog("  Bild #$index: Netzwerkfehler: ${e.message}")
          return false
        }
      } catch (e: Exception) {
        appendLog("  Bild #$index: Unerwarteter Fehler: ${e.message}")
        return false
      }
    }
    return false
  }

  private fun createForegroundInfo(
    progress: Int,
    max: Int,
    statusText: String,
    indeterminate: Boolean
  ): ForegroundInfo {
    val cancelPendingIntent = WorkManager.getInstance(appContext)
      .createCancelPendingIntent(id)
    val notificationIntent = Intent(appContext, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val contentPendingIntent = PendingIntent.getActivity(
      appContext,
      0,
      notificationIntent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val builder = NotificationCompat.Builder(appContext, NOTIFICATION_CHANNEL_ID)
      .setContentTitle(appContext.getString(R.string.notification_title))
      .setContentText(statusText)
      .setSmallIcon(R.drawable.ic_launcher_foreground)
      .setOngoing(true)
      .setContentIntent(contentPendingIntent)
      .addAction(
        android.R.drawable.ic_menu_close_clear_cancel,
        appContext.getString(R.string.notification_cancel),
        cancelPendingIntent
      )

    if (max > 0) {
      builder.setProgress(max, progress, false)
    } else if (indeterminate) {
      builder.setProgress(0, 0, true)
    }

    val notification = builder.build()
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      ForegroundInfo(
        NOTIFICATION_ID,
        notification,
        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
      )
    } else {
      ForegroundInfo(NOTIFICATION_ID, notification)
    }
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        NOTIFICATION_CHANNEL_ID,
        appContext.getString(R.string.notification_channel_name),
        NotificationManager.IMPORTANCE_LOW
      ).apply {
        description = appContext.getString(R.string.notification_channel_desc)
        setShowBadge(false)
      }
      notificationManager.createNotificationChannel(channel)
    }
  }
}
