package com.example.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.ui.theme.BerryPrimary
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.HeartRed
import com.example.ui.theme.MatteBorder
import com.example.ui.theme.MatteBorderSubtle
import com.example.ui.theme.MatteCardBg
import com.example.ui.theme.MattePinkSurface
import com.example.ui.theme.TextDeepCharcoal
import com.example.ui.theme.TextMutedPlum
import com.example.ui.theme.TextPlumMedium
import com.example.ui.theme.TextWhite

@Composable
fun ImageViewerDialog(
  localUri: String,
  fileName: String,
  width: Int = 0,
  height: Int = 0,
  fileSize: Long = 0L,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(22.dp),
      color = MatteCardBg,
      border = BorderStroke(1.dp, MatteBorder),
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp)
      ) {
        // Header with title and close
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = fileName,
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = TextDeepCharcoal,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            val info = buildString {
              if (width > 0 && height > 0) append("${width} × ${height} px • ")
              if (fileSize > 0) append(formatFileSize(fileSize))
            }
            if (info.isNotBlank()) {
              Text(
                text = info,
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = BerryPrimary
              )
            }
          }
          IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Schließen",
              tint = TextDeepCharcoal
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Image display
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 180.dp, max = 340.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MattePinkSurface)
            .border(1.dp, MatteBorderSubtle, RoundedCornerShape(14.dp)),
          contentAlignment = Alignment.Center
        ) {
          AsyncImage(
            model = localUri,
            contentDescription = fileName,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxWidth()
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Action Buttons: Share & Open
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          FilledTonalButton(
            onClick = {
              try {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                  type = "image/*"
                  putExtra(Intent.EXTRA_STREAM, Uri.parse(localUri))
                  addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(shareIntent, "Bild teilen"))
              } catch (_: Exception) {}
            },
            colors = ButtonDefaults.filledTonalButtonColors(
              containerColor = MattePinkSurface,
              contentColor = TextDeepCharcoal
            ),
            border = BorderStroke(1.dp, MatteBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .weight(1f)
              .height(42.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Share,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
              tint = BerryPrimary
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Teilen", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          }

          Button(
            onClick = {
              try {
                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                  setDataAndType(Uri.parse(localUri), "image/*")
                  addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(viewIntent)
              } catch (_: Exception) {}
            },
            colors = ButtonDefaults.buttonColors(
              containerColor = HeartRed,
              contentColor = TextWhite
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .weight(1f)
              .height(42.dp)
          ) {
            Icon(
              imageVector = Icons.Default.OpenInNew,
              contentDescription = null,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Öffnen", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}
