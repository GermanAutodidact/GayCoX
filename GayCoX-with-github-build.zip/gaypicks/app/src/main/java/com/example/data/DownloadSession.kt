package com.example.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(tableName = "download_sessions")
data class DownloadSession(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val title: String,
  val sourceUrl: String,
  val domain: String,
  val imageCount: Int,
  val totalBytes: Long,
  val folderName: String,
  val completedAt: Long = System.currentTimeMillis()
)

@Entity(
  tableName = "session_images",
  foreignKeys = [
    ForeignKey(
      entity = DownloadSession::class,
      parentColumns = ["id"],
      childColumns = ["sessionId"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [Index(value = ["sessionId"])]
)
data class SessionImage(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val sessionId: Long,
  val originalUrl: String,
  val localUri: String,
  val fileName: String,
  val fileSize: Long = 0L,
  val width: Int = 0,
  val height: Int = 0
)

data class SessionWithImages(
  @Embedded val session: DownloadSession,
  @Relation(
    parentColumn = "id",
    entityColumn = "sessionId"
  )
  val images: List<SessionImage>
)
