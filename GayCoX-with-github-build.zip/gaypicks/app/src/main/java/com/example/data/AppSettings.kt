package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "gaycox_settings")

data class AppSettings(
  val concurrency: Int = 4,
  val minDimensionPx: Int = 400,
  val minSizeKb: Int = 100,
  val maxSizeKb: Int = 300,
  val scrollTimeoutSec: Int = 60,
  val maxPageDepth: Int = 5,
  val wifiOnly: Boolean = false,
  val autoImportClipboard: Boolean = false
)

class SettingsRepository(private val context: Context) {
  companion object {
    val KEY_CONCURRENCY = intPreferencesKey("concurrency")
    val KEY_MIN_DIMENSION_PX = intPreferencesKey("min_dimension_px")
    val KEY_MIN_SIZE_KB = intPreferencesKey("min_size_kb")
    val KEY_MAX_SIZE_KB = intPreferencesKey("max_size_kb")
    val KEY_SCROLL_TIMEOUT_SEC = intPreferencesKey("scroll_timeout_sec")
    val KEY_MAX_PAGE_DEPTH = intPreferencesKey("max_page_depth")
    val KEY_WIFI_ONLY = booleanPreferencesKey("wifi_only")
    val KEY_AUTO_IMPORT_CLIPBOARD = booleanPreferencesKey("auto_import_clipboard")
  }

  val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { preferences ->
    AppSettings(
      concurrency = preferences[KEY_CONCURRENCY] ?: 4,
      minDimensionPx = preferences[KEY_MIN_DIMENSION_PX] ?: 400,
      minSizeKb = preferences[KEY_MIN_SIZE_KB] ?: 100,
      maxSizeKb = preferences[KEY_MAX_SIZE_KB] ?: 300,
      scrollTimeoutSec = preferences[KEY_SCROLL_TIMEOUT_SEC] ?: 60,
      maxPageDepth = preferences[KEY_MAX_PAGE_DEPTH] ?: 5,
      wifiOnly = preferences[KEY_WIFI_ONLY] ?: false,
      autoImportClipboard = preferences[KEY_AUTO_IMPORT_CLIPBOARD] ?: false
    )
  }

  suspend fun updateConcurrency(value: Int) {
    context.dataStore.edit { it[KEY_CONCURRENCY] = value.coerceIn(1, 8) }
  }

  suspend fun updateMinDimensionPx(value: Int) {
    context.dataStore.edit { it[KEY_MIN_DIMENSION_PX] = value.coerceAtLeast(0) }
  }

  suspend fun updateMinSizeKb(value: Int) {
    context.dataStore.edit { it[KEY_MIN_SIZE_KB] = value.coerceAtLeast(0) }
  }

  suspend fun updateMaxSizeKb(value: Int) {
    context.dataStore.edit { it[KEY_MAX_SIZE_KB] = value.coerceAtLeast(50) }
  }

  suspend fun updateScrollTimeoutSec(value: Int) {
    context.dataStore.edit { it[KEY_SCROLL_TIMEOUT_SEC] = value.coerceIn(5, 300) }
  }

  suspend fun updateMaxPageDepth(value: Int) {
    context.dataStore.edit { it[KEY_MAX_PAGE_DEPTH] = value.coerceIn(1, 20) }
  }

  suspend fun updateWifiOnly(value: Boolean) {
    context.dataStore.edit { it[KEY_WIFI_ONLY] = value }
  }

  suspend fun updateAutoImportClipboard(value: Boolean) {
    context.dataStore.edit { it[KEY_AUTO_IMPORT_CLIPBOARD] = value }
  }
}
