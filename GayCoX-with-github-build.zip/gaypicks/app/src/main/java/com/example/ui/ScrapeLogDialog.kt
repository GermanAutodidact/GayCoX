package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.QueueItem
import com.example.ui.theme.BerryPrimary
import com.example.ui.theme.HeartRed
import com.example.ui.theme.MatteBorder
import com.example.ui.theme.MatteCardBg
import com.example.ui.theme.MattePinkSurface
import com.example.ui.theme.TextDeepCharcoal
import com.example.ui.theme.TextPlumMedium
import com.example.ui.theme.TextWhite

@Composable
fun ScrapeLogDialog(
  item: QueueItem,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val scrollState = rememberScrollState()

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MatteCardBg,
      border = BorderStroke(1.dp, MatteBorder),
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(max = 620.dp)
        .testTag("scrape_log_dialog")
    ) {
      Column(
        modifier = Modifier.padding(16.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Description,
              contentDescription = null,
              tint = HeartRed,
              modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "Fehler- & Scan-Protokoll",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextDeepCharcoal
              )
              Text(
                text = item.domain.ifBlank { item.url },
                style = MaterialTheme.typography.bodySmall,
                color = TextPlumMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Schließen",
              tint = TextDeepCharcoal
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Log Console Box
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MattePinkSurface,
          border = BorderStroke(1.dp, MatteBorder),
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f, fill = false)
        ) {
          Column(
            modifier = Modifier
              .padding(12.dp)
              .verticalScroll(scrollState)
          ) {
            val displayLog = if (item.logReport.isNotBlank()) {
              item.logReport
            } else if (item.errorMessage != null) {
              "Fehlermeldung: ${item.errorMessage}\nKein erweitertes Protokoll verfügbar."
            } else {
              "Protokoll wird während des Scans und Downloads aufgezeichnet..."
            }
            Text(
              text = displayLog,
              fontFamily = FontFamily.Monospace,
              fontSize = 11.sp,
              lineHeight = 16.sp,
              color = TextDeepCharcoal
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Action Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          FilledTonalButton(
            onClick = {
              val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
              val clip = ClipData.newPlainText("GayCoX Scan Log", item.logReport.ifBlank { item.errorMessage ?: "" })
              clipboard.setPrimaryClip(clip)
              Toast.makeText(context, "Protokoll in Zwischenablage kopiert", Toast.LENGTH_SHORT).show()
            },
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
              containerColor = MattePinkSurface,
              contentColor = TextDeepCharcoal
            ),
            modifier = Modifier.testTag("copy_log_button")
          ) {
            Icon(
              imageVector = Icons.Default.ContentCopy,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
              tint = BerryPrimary
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Log kopieren", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          }

          Button(
            onClick = onDismiss,
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = HeartRed,
              contentColor = TextWhite
            )
          ) {
            Text(text = "Schließen", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}
