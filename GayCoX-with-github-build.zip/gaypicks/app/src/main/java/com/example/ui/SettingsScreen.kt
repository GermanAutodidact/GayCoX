package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.AppSettings
import com.example.ui.MatteHeartBackground
import com.example.ui.theme.BerryPrimary
import com.example.ui.theme.HeartRed
import com.example.ui.theme.MatteBorder
import com.example.ui.theme.MatteBorderSubtle
import com.example.ui.theme.MatteCardBg
import com.example.ui.theme.MattePinkSurface
import com.example.ui.theme.TextDeepCharcoal
import com.example.ui.theme.TextMutedPlum
import com.example.ui.theme.TextPlumMedium
import com.example.ui.theme.TextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
  settings: AppSettings,
  onConcurrencyChange: (Int) -> Unit,
  onMinDimensionChange: (Int) -> Unit,
  onMinSizeKbChange: (Int) -> Unit,
  onMaxSizeKbChange: (Int) -> Unit,
  onScrollTimeoutChange: (Int) -> Unit,
  onMaxDepthChange: (Int) -> Unit,
  onWifiOnlyChange: (Boolean) -> Unit,
  onAutoImportClipboardChange: (Boolean) -> Unit,
  onNavigateBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler {
    onNavigateBack()
  }

  MatteHeartBackground(modifier = modifier) {
    Scaffold(
      modifier = Modifier.testTag("settings_screen"),
      containerColor = Color.Transparent,
      topBar = {
        TopAppBar(
          title = {
            Text(
              text = stringResource(R.string.settings_title),
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              color = TextDeepCharcoal,
              letterSpacing = 0.5.sp
            )
          },
          navigationIcon = {
            IconButton(
              onClick = onNavigateBack,
              modifier = Modifier.testTag("settings_back_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = stringResource(R.string.back),
                tint = TextDeepCharcoal
              )
            }
          },
          colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color.Transparent
          )
        )
      }
    ) { innerPadding ->
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .padding(horizontal = 16.dp)
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        Spacer(modifier = Modifier.height(4.dp))

        // 1. Parallele Downloads (Concurrency)
        SettingsSliderCard(
          icon = Icons.Default.Memory,
          title = stringResource(R.string.concurrency_label),
          description = stringResource(R.string.concurrency_desc),
          valueText = "${settings.concurrency}",
          value = settings.concurrency.toFloat(),
          valueRange = 1f..8f,
          steps = 6,
          onValueChange = { onConcurrencyChange(it.toInt()) },
          testTag = "concurrency_slider"
        )

        // 2. Mindest-Bildabmessung (Filtert Icons & Tracker aus)
        SettingsSliderCard(
          icon = Icons.Default.AspectRatio,
          title = stringResource(R.string.min_dimension_label),
          description = stringResource(R.string.min_dimension_desc),
          valueText = "${settings.minDimensionPx} PX",
          value = settings.minDimensionPx.toFloat(),
          valueRange = 100f..2000f,
          steps = 18,
          onValueChange = { onMinDimensionChange(it.toInt()) },
          testTag = "min_dimension_slider"
        )

        // 3. Mindest-Dateigröße (z.B. mindestens 100 KB für Originale)
        SettingsSliderCard(
          icon = Icons.Default.SdStorage,
          title = stringResource(R.string.min_size_label),
          description = stringResource(R.string.min_size_desc),
          valueText = "${settings.minSizeKb} KB",
          value = settings.minSizeKb.toFloat(),
          valueRange = 0f..2000f,
          steps = 39,
          onValueChange = { onMinSizeKbChange(it.toInt()) },
          testTag = "min_size_slider"
        )

        // 4. Maximale Dateigröße (Verkleinerung auf max. 300 KB & JPG-Konvertierung)
        SettingsSliderCard(
          icon = Icons.Default.AspectRatio,
          title = stringResource(R.string.max_size_label),
          description = stringResource(R.string.max_size_desc),
          valueText = "${settings.maxSizeKb} KB",
          value = settings.maxSizeKb.toFloat(),
          valueRange = 100f..1500f,
          steps = 14,
          onValueChange = { onMaxSizeKbChange(it.toInt()) },
          testTag = "max_size_slider"
        )

        // 5. Scroll Timeout
        SettingsSliderCard(
          icon = Icons.Default.Autorenew,
          title = stringResource(R.string.scroll_timeout_label),
          description = stringResource(R.string.scroll_timeout_desc),
          valueText = "${settings.scrollTimeoutSec} S",
          value = settings.scrollTimeoutSec.toFloat(),
          valueRange = 10f..180f,
          steps = 16,
          onValueChange = { onScrollTimeoutChange(it.toInt()) },
          testTag = "scroll_timeout_slider"
        )

        // 6. Maximale Seitentiefe
        SettingsSliderCard(
          icon = Icons.Default.Layers,
          title = stringResource(R.string.max_depth_label),
          description = stringResource(R.string.max_depth_desc),
          valueText = "${settings.maxPageDepth} KLICKS",
          value = settings.maxPageDepth.toFloat(),
          valueRange = 1f..15f,
          steps = 13,
          onValueChange = { onMaxDepthChange(it.toInt()) },
          testTag = "max_depth_slider"
        )

        // 7. Nur WLAN
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(18.dp),
          border = BorderStroke(1.dp, MatteBorder),
          colors = CardDefaults.cardColors(
            containerColor = MatteCardBg
          )
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = MattePinkSurface,
              modifier = Modifier.size(38.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.Wifi,
                  contentDescription = null,
                  tint = BerryPrimary,
                  modifier = Modifier.size(20.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = stringResource(R.string.wifi_only_label),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextDeepCharcoal
              )
              Text(
                text = stringResource(R.string.wifi_only_desc),
                style = MaterialTheme.typography.bodySmall,
                color = TextPlumMedium
              )
            }
            Switch(
              checked = settings.wifiOnly,
              onCheckedChange = onWifiOnlyChange,
              colors = SwitchDefaults.colors(
                checkedThumbColor = TextWhite,
                checkedTrackColor = HeartRed,
                uncheckedThumbColor = TextMutedPlum,
                uncheckedTrackColor = MattePinkSurface,
                uncheckedBorderColor = MatteBorder
              ),
              modifier = Modifier.testTag("wifi_only_switch")
            )
          }
        }

        // 8. Autonome Zwischenablagen-Erkennung
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(18.dp),
          border = BorderStroke(1.dp, MatteBorder),
          colors = CardDefaults.cardColors(
            containerColor = MatteCardBg
          )
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = MattePinkSurface,
              modifier = Modifier.size(38.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.Autorenew,
                  contentDescription = null,
                  tint = BerryPrimary,
                  modifier = Modifier.size(20.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = stringResource(R.string.auto_clipboard_label),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextDeepCharcoal
              )
              Text(
                text = stringResource(R.string.auto_clipboard_desc),
                style = MaterialTheme.typography.bodySmall,
                color = TextPlumMedium
              )
            }
            Switch(
              checked = settings.autoImportClipboard,
              onCheckedChange = onAutoImportClipboardChange,
              colors = SwitchDefaults.colors(
                checkedThumbColor = TextWhite,
                checkedTrackColor = HeartRed,
                uncheckedThumbColor = TextMutedPlum,
                uncheckedTrackColor = MattePinkSurface,
                uncheckedBorderColor = MatteBorder
              ),
              modifier = Modifier.testTag("auto_clipboard_switch")
            )
          }
        }

        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  }
}

@Composable
fun SettingsSliderCard(
  icon: ImageVector,
  title: String,
  description: String,
  valueText: String,
  value: Float,
  valueRange: ClosedFloatingPointRange<Float>,
  steps: Int,
  onValueChange: (Float) -> Unit,
  testTag: String,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(18.dp),
    border = BorderStroke(1.dp, MatteBorder),
    colors = CardDefaults.cardColors(
      containerColor = MatteCardBg
    )
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MattePinkSurface,
          modifier = Modifier.size(38.dp)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = icon,
              contentDescription = null,
              tint = BerryPrimary,
              modifier = Modifier.size(20.dp)
            )
          }
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextDeepCharcoal
          )
          Text(
            text = description,
            style = MaterialTheme.typography.bodySmall,
            color = TextPlumMedium
          )
        }
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MattePinkSurface,
          border = BorderStroke(1.dp, MatteBorder)
        ) {
          Text(
            text = valueText,
            fontFamily = FontFamily.Monospace,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = HeartRed,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Slider(
        value = value,
        onValueChange = onValueChange,
        valueRange = valueRange,
        steps = steps,
        colors = SliderDefaults.colors(
          thumbColor = HeartRed,
          activeTrackColor = HeartRed,
          inactiveTrackColor = MattePinkSurface,
          activeTickColor = BerryPrimary,
          inactiveTickColor = MatteBorder
        ),
        modifier = Modifier.testTag(testTag)
      )
    }
  }
}
