package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val GayCoXLightColorScheme =
  lightColorScheme(
    primary = BerryPrimary,
    onPrimary = TextWhite,
    primaryContainer = MattePinkSurface,
    onPrimaryContainer = BerryPrimary,
    secondary = HeartRed,
    onSecondary = TextWhite,
    secondaryContainer = SoftHeartSurface,
    onSecondaryContainer = HeartRedDeep,
    tertiary = RubyAccent,
    onTertiary = TextWhite,
    background = MattePastelPink,
    onBackground = TextDeepCharcoal,
    surface = MatteCardBg,
    onSurface = TextDeepCharcoal,
    surfaceVariant = MattePinkSurface,
    onSurfaceVariant = TextPlumMedium,
    outline = MatteBorder,
    outlineVariant = MatteBorderSubtle,
    error = StatusError,
    onError = TextWhite
  )

@Composable
fun GayCoXTheme(
  darkTheme: Boolean = false,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = GayCoXLightColorScheme,
    typography = Typography,
    content = content
  )
}
