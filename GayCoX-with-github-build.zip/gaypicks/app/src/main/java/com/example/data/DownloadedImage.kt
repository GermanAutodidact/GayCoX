package com.example.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
  tableName = "downloaded_images",
  foreignKeys = [
    ForeignKey(
      entity = QueueItem::class,
      parentColumns = ["id"],
      childColumns = ["queueItemId"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [Index(value = ["queueItemId"])]
)
data class DownloadedImage(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val queueItemId: Long,
  val originalUrl: String,
  val localUri: String,
  val fileName: String,
  val fileSize: Long = 0L,
  val width: Int = 0,
  val height: Int = 0,
  val createdAt: Long = System.currentTimeMillis()
)
