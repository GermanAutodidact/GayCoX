package com.example.ui

import android.app.Application
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.AppSettings
import com.example.data.BatchRepository
import com.example.data.DownloadedImage
import com.example.data.PreviewCandidate
import com.example.data.QueueItem
import com.example.data.QueueStatus
import com.example.data.SessionWithImages
import com.example.data.SettingsRepository
import com.example.scraper.UrlNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.jsoup.Jsoup
import java.io.BufferedReader
import java.io.InputStreamReader

data class MainUiState(
  val queueItems: List<QueueItem> = emptyList(),
  val settings: AppSettings = AppSettings(),
  val isWorking: Boolean = false,
  val expandedItemIds: Set<Long> = emptySet(),
  val itemImages: Map<Long, List<DownloadedImage>> = emptyMap(),
  val detectedClipboardCount: Int = 0,
  val detectedClipboardRaw: String = "",
  val historySessions: List<SessionWithImages> = emptyList()
)

class BatchViewModel(application: Application) : AndroidViewModel(application) {
  private val database = AppDatabase.getInstance(application)
  private val settingsRepository = SettingsRepository(application)
  private val repository = BatchRepository(application, database.queueDao(), database.sessionDao(), settingsRepository)
  private val clipboardManager =
    application.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

  private val _inputText = MutableStateFlow("")
  val inputText: StateFlow<String> = _inputText.asStateFlow()

  private val _expandedItemIds = MutableStateFlow<Set<Long>>(emptySet())
  private val _itemImages = MutableStateFlow<Map<Long, List<DownloadedImage>>>(emptyMap())
  private val _detectedClipboardCount = MutableStateFlow(0)
  private val _detectedClipboardRaw = MutableStateFlow("")

  private val _snackbarMessage = MutableSharedFlow<String>(extraBufferCapacity = 1)
  val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

  init {
    viewModelScope.launch {
      repository.resetInterruptedItems()
      checkClipboardAutonomously()
    }
  }

  private data class ClipboardState(val count: Int, val raw: String)
  private data class CoreState(
    val items: List<QueueItem>,
    val settings: AppSettings,
    val expandedIds: Set<Long>,
    val imagesMap: Map<Long, List<DownloadedImage>>,
    val sessions: List<SessionWithImages>
  )

  private val _clipboardState = combine(_detectedClipboardCount, _detectedClipboardRaw) { count, raw ->
    ClipboardState(count, raw)
  }

  private val _coreState = combine(
    repository.allQueueItems,
    settingsRepository.settingsFlow,
    _expandedItemIds,
    _itemImages,
    repository.allSessionsWithImages
  ) { items, settings, expandedIds, imagesMap, sessions ->
    CoreState(items, settings, expandedIds, imagesMap, sessions)
  }

  val uiState: StateFlow<MainUiState> = combine(_coreState, _clipboardState) { core, clip ->
    val hasActiveWork = core.items.any {
      it.status == QueueStatus.SCANNING ||
        it.status == QueueStatus.DOWNLOADING ||
        it.status == QueueStatus.READY_TO_DOWNLOAD
    }
    MainUiState(
      queueItems = core.items,
      settings = core.settings,
      isWorking = hasActiveWork,
      expandedItemIds = core.expandedIds,
      itemImages = core.imagesMap,
      detectedClipboardCount = clip.count,
      detectedClipboardRaw = clip.raw,
      historySessions = core.sessions
    )
  }.stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = MainUiState()
  )

  fun onInputTextChanged(text: String) {
    _inputText.value = text
  }

  fun addInputToQueue() {
    val text = _inputText.value
    if (text.isBlank()) return
    viewModelScope.launch {
      val added = repository.addUrlsToQueue(text)
      if (added > 0) {
        _inputText.value = ""
        _snackbarMessage.emit("$added URL(s) hinzugefügt")
      } else {
        _snackbarMessage.emit("Keine neuen gültigen URLs gefunden")
      }
    }
  }

  fun checkClipboardAutonomously() {
    viewModelScope.launch {
      val clip = clipboardManager.primaryClip ?: return@launch
      if (clip.itemCount == 0) return@launch
      val text = clip.getItemAt(0)?.coerceToText(getApplication())?.toString() ?: return@launch
      val extracted = UrlNormalizer.extractUrls(text)
      if (extracted.isEmpty()) return@launch
      val currentQueue = repository.allQueueItems.first().map { it.url }.toSet()
      val newUrls = extracted.filter { !currentQueue.contains(it) }
      if (newUrls.isEmpty()) return@launch
      val settings = settingsRepository.settingsFlow.first()
      if (settings.autoImportClipboard) {
        val added = repository.addUrlsToQueue(text)
        if (added > 0) {
          _snackbarMessage.emit("⚡ Autonom: $added URLs aus Zwischenablage importiert")
        }
      } else {
        _detectedClipboardCount.value = newUrls.size
        _detectedClipboardRaw.value = text
      }
    }
  }

  fun importDetectedClipboardUrls() {
    val raw = _detectedClipboardRaw.value
    dismissClipboardBanner()
    if (raw.isNotBlank()) {
      viewModelScope.launch {
        val added = repository.addUrlsToQueue(raw)
        if (added > 0) {
          _snackbarMessage.emit("$added Tab(s) übernommen")
        }
      }
    }
  }

  fun dismissClipboardBanner() {
    _detectedClipboardCount.value = 0
    _detectedClipboardRaw.value = ""
  }

  fun importFromClipboard() {
    val clip = clipboardManager.primaryClip
    if (clip == null || clip.itemCount == 0) {
      viewModelScope.launch { _snackbarMessage.emit("Zwischenablage ist leer") }
      return
    }
    val text = clip.getItemAt(0)?.coerceToText(getApplication())?.toString() ?: ""
    if (text.isBlank()) {
      viewModelScope.launch { _snackbarMessage.emit("Kein Text in der Zwischenablage") }
      return
    }
    viewModelScope.launch {
      val added = repository.addUrlsToQueue(text)
      if (added > 0) {
        _snackbarMessage.emit("$added URL(s) aus Zwischenablage hinzugefügt")
      } else {
        _snackbarMessage.emit("Keine neuen URLs in der Zwischenablage gefunden")
      }
    }
  }

  fun importFromFile(uri: Uri) {
    viewModelScope.launch {
      val count = withContext(Dispatchers.IO) {
        try {
          val context = getApplication<Application>()
          val inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext 0
          val content = BufferedReader(InputStreamReader(inputStream)).use { it.readText() }
          val urls = mutableListOf<String>()
          if (content.contains("<html", ignoreCase = true) || content.contains("<a ", ignoreCase = true)) {
            val doc = Jsoup.parse(content)
            val links = doc.select("a[href]")
            for (link in links) {
              val href = link.attr("href")
              if (UrlNormalizer.isValidHttpUrl(href)) {
                urls.add(UrlNormalizer.normalizeWebUrl(href))
              }
            }
          }
          urls.addAll(UrlNormalizer.extractUrls(content))
          val distinctUrls = urls.distinct()
          if (distinctUrls.isEmpty()) return@withContext 0
          repository.addUrlsToQueue(distinctUrls.joinToString("\n"))
        } catch (_: Exception) {
          0
        }
      }
      if (count > 0) {
        _snackbarMessage.emit("📁 $count Tab(s) aus Datei importiert")
      } else {
        _snackbarMessage.emit("Keine gültigen URLs in der Datei gefunden")
      }
    }
  }

  fun handleSharedUrl(sharedText: String) {
    viewModelScope.launch {
      val added = repository.addUrlsToQueue(sharedText)
      if (added > 0) {
        _snackbarMessage.emit("URL(s) zur Queue hinzugefügt")
      }
    }
  }

  fun startAll() {
    viewModelScope.launch {
      repository.startAll()
      _snackbarMessage.emit("Download gestartet")
    }
  }

  fun clearCompleted() {
    viewModelScope.launch {
      repository.deleteCompletedItems()
      _snackbarMessage.emit("Fertige Downloads entfernt")
    }
  }

  fun clearAll() {
    viewModelScope.launch {
      repository.clearAll()
      _snackbarMessage.emit("Queue geleert")
    }
  }

  fun deleteSession(sessionId: Long) {
    viewModelScope.launch {
      repository.deleteSession(sessionId)
      _snackbarMessage.emit("Sitzung gelöscht")
    }
  }

  fun clearAllHistory() {
    viewModelScope.launch {
      repository.clearAllSessions()
      _snackbarMessage.emit("Download-Historie geleert")
    }
  }

  fun deleteItem(id: Long) {
    viewModelScope.launch {
      repository.deleteQueueItem(id)
    }
  }

  fun retryItem(id: Long) {
    viewModelScope.launch {
      repository.retryItem(id)
      _snackbarMessage.emit("Erneuter Versuch gestartet")
    }
  }

  fun retryAllErrors() {
    viewModelScope.launch {
      repository.retryAllErrors()
      _snackbarMessage.emit("Alle Fehler werden erneut versucht")
    }
  }

  fun toggleItemExpansion(id: Long) {
    val current = _expandedItemIds.value
    if (current.contains(id)) {
      _expandedItemIds.value = current - id
    } else {
      _expandedItemIds.value = current + id
      loadImagesForItem(id)
    }
  }

  private fun loadImagesForItem(id: Long) {
    viewModelScope.launch {
      repository.getImagesForQueue(id).collect { images ->
        _itemImages.value = _itemImages.value + (id to images)
      }
    }
  }

  // Settings
  fun updateConcurrency(value: Int) = viewModelScope.launch {
    settingsRepository.updateConcurrency(value)
  }

  fun updateMinDimensionPx(value: Int) = viewModelScope.launch {
    settingsRepository.updateMinDimensionPx(value)
  }

  fun updateMinSizeKb(value: Int) = viewModelScope.launch {
    settingsRepository.updateMinSizeKb(value)
  }

  fun updateMaxSizeKb(value: Int) = viewModelScope.launch {
    settingsRepository.updateMaxSizeKb(value)
  }

  fun updateScrollTimeoutSec(value: Int) = viewModelScope.launch {
    settingsRepository.updateScrollTimeoutSec(value)
  }

  fun updateMaxPageDepth(value: Int) = viewModelScope.launch {
    settingsRepository.updateMaxPageDepth(value)
  }

  fun updateWifiOnly(value: Boolean) = viewModelScope.launch {
    settingsRepository.updateWifiOnly(value)
  }

  fun updateAutoImportClipboard(value: Boolean) = viewModelScope.launch {
    settingsRepository.updateAutoImportClipboard(value)
  }

  // Preview Candidate State & Selection
  private val _previewCandidates = MutableStateFlow<List<PreviewCandidate>>(emptyList())
  val previewCandidates: StateFlow<List<PreviewCandidate>> = _previewCandidates.asStateFlow()

  private val _previewTitle = MutableStateFlow("")
  val previewTitle: StateFlow<String> = _previewTitle.asStateFlow()

  private val _previewDomain = MutableStateFlow("")
  val previewDomain: StateFlow<String> = _previewDomain.asStateFlow()

  fun openPreview(title: String, domain: String, urls: List<String>) {
    _previewTitle.value = title
    _previewDomain.value = domain
    _previewCandidates.value = urls.map { url ->
      PreviewCandidate(
        originalUrl = url,
        thumbnailUrl = url,
        isSelected = true
      )
    }
  }

  fun openPreviewWithCandidates(title: String, domain: String, candidates: List<PreviewCandidate>) {
    _previewTitle.value = title
    _previewDomain.value = domain
    _previewCandidates.value = candidates
  }

  fun togglePreviewCandidate(id: String) {
    _previewCandidates.value = _previewCandidates.value.map {
      if (it.id == id) it.copy(isSelected = !it.isSelected) else it
    }
  }

  fun selectAllPreviewCandidates() {
    _previewCandidates.value = _previewCandidates.value.map { it.copy(isSelected = true) }
  }

  fun deselectAllPreviewCandidates() {
    _previewCandidates.value = _previewCandidates.value.map { it.copy(isSelected = false) }
  }

  private var previewSourceQueueItemId: Long? = null

  fun openPreviewFromQueueItem(item: QueueItem): Boolean {
    val candidates = mutableListOf<PreviewCandidate>()
    if (item.candidateUrlsJson.isNotBlank()) {
      try {
        val jsonArray = JSONArray(item.candidateUrlsJson)
        for (i in 0 until jsonArray.length()) {
          val el = jsonArray.opt(i)
          when (el) {
            is org.json.JSONObject -> {
              val thumb = el.optString("t").ifBlank { el.optString("thumb") }
              val full = el.optString("f").ifBlank { el.optString("full") }
              if (full.isNotBlank()) {
                candidates.add(
                  PreviewCandidate(
                    originalUrl = full,
                    thumbnailUrl = thumb.ifBlank { full },
                    isSelected = true
                  )
                )
              }
            }
            else -> {
              val u = jsonArray.optString(i)
              if (u.isNotBlank() && !u.startsWith("{")) {
                candidates.add(
                  PreviewCandidate(originalUrl = u, thumbnailUrl = u, isSelected = true)
                )
              }
            }
          }
        }
      } catch (_: Exception) {}
    }
    if (candidates.isEmpty()) {
      val existingImages = _itemImages.value[item.id] ?: emptyList()
      candidates.addAll(
        existingImages.map {
          PreviewCandidate(originalUrl = it.originalUrl, thumbnailUrl = it.originalUrl, isSelected = true)
        }
      )
    }
    if (candidates.isNotEmpty()) {
      previewSourceQueueItemId = item.id
      val title = item.title.ifBlank { item.domain.ifBlank { item.url } }
      openPreviewWithCandidates(title, item.domain, candidates)
      return true
    }
    return false
  }

  /**
   * User hat in der Vorschau bestätigt:
   * - Speichert nur die ausgewählten Fullsize-URLs
   * - Setzt Status auf READY_TO_DOWNLOAD
   * - Startet den Worker für Phase 2
   */
  fun downloadSelectedPreviewCandidates(candidates: List<PreviewCandidate>) {
    val selected = candidates.filter { it.isSelected }
    if (selected.isEmpty()) return
    val itemId = previewSourceQueueItemId
    viewModelScope.launch {
      if (itemId != null) {
        repository.confirmSelectionAndDownload(itemId, selected.map { it.originalUrl })
        _snackbarMessage.emit("${selected.size} Bild(er) werden heruntergeladen …")
      } else {
        // Fallback: als neue Queue-Einträge (Direkt-URLs)
        val urlsText = selected.joinToString("\n") { it.originalUrl }
        repository.addUrlsToQueue(urlsText)
        repository.startAll()
      }
      previewSourceQueueItemId = null
    }
  }

  class Factory(private val app: Application) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
      return BatchViewModel(app) as T
    }
  }
}
