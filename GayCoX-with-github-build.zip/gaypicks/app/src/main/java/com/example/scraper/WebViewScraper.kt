package com.example.scraper

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.data.AppSettings
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.jsoup.Jsoup
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/**
 * [imageUrls] bleibt aus Kompatibilitätsgründen die Liste der Fullsize-URLs.
 * [candidates] enthält Paare Thumbnail → Fullsize (für die Vorschau-Auswahl).
 */
data class ImageCandidate(
  val thumbnailUrl: String,
  val fullUrl: String
)

data class ScrapeResult(
  val title: String,
  val domain: String,
  val imageUrls: List<String>,
  val candidates: List<ImageCandidate> = emptyList(),
  val cookies: String
)

class WebViewScraper(
  private val context: Context,
  private val okHttpClient: OkHttpClient
) {
  companion object {
    private const val DESKTOP_UA =
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    private const val SCROLL_JS =
      "(function(){window.__done=false;let last=0,same=0;const t=setInterval(()=>{window.scrollBy(0,innerHeight*0.9);const h=(document.body?document.body.scrollHeight:0)+document.images.length;same=(h===last)?same+1:0;last=h;if(same>=3){clearInterval(t);window.__done=true;}},700);})()"
    private const val CLICK_NEXT_JS =
      """(function() {
        const keywords = ['mehr', 'load more', 'show more', 'weiter', 'next', 'mehr laden', 'weitere bilder', 'view more'];
        const relNext = document.querySelector('[rel="next"]');
        if (relNext) { relNext.click(); return true; }
        const elements = Array.from(document.querySelectorAll('button, a, [role="button"], .load-more, .btn-more'));
        for (const el of elements) {
          const text = (el.innerText || el.textContent || '').trim().toLowerCase();
          if (keywords.some(k => text.includes(k))) {
            el.click();
            return true;
          }
        }
        return false;
      })()"""
    private const val EXTRACT_DOM_IMAGES_JS =
      """(function() {
        const found = new Set();
        document.querySelectorAll('img').forEach(img => {
          const dataHigh = img.getAttribute('data-original') || img.getAttribute('data-highres') ||
                            img.getAttribute('data-full') || img.getAttribute('data-zoom-image') ||
                            img.getAttribute('data-large-src') || img.getAttribute('data-src') ||
                            img.getAttribute('data-lazy-src') || img.getAttribute('data-url');
          if (dataHigh) found.add(dataHigh);
          const srcset = img.getAttribute('srcset') || img.getAttribute('data-srcset');
          if (srcset) {
            srcset.split(',').forEach(s => {
              const part = s.trim().split(/\s+/)[0];
              if (part) found.add(part);
            });
          }
          if (img.currentSrc) found.add(img.currentSrc);
          if (img.src) found.add(img.src);
        });
        document.querySelectorAll('picture source').forEach(src => {
          const srcset = src.getAttribute('srcset') || src.getAttribute('data-srcset');
          if (srcset) {
            srcset.split(',').forEach(s => {
              const part = s.trim().split(/\s+/)[0];
              if (part) found.add(part);
            });
          }
        });
        document.querySelectorAll('*').forEach(el => {
          try {
            const bg = window.getComputedStyle(el).backgroundImage;
            if (bg && bg !== 'none') {
              const match = bg.match(/url\(['"]?(.*?)['"]?\)/i);
              if (match && match[1]) found.add(match[1]);
            }
          } catch(e) {}
        });
        document.querySelectorAll('a[href]').forEach(a => {
          const href = a.getAttribute('href');
          if (href && /\.(jpg|jpeg|png|webp|gif)(\?.*)?$/i.test(href)) {
            found.add(href);
          }
        });
        document.querySelectorAll('meta[property="og:image"], meta[name="twitter:image"]').forEach(m => {
          const content = m.getAttribute('content');
          if (content) found.add(content);
        });
        document.querySelectorAll('.modal, [role="dialog"], .scene-modal, #scene-modal--images, .lightbox, .pswp, .gallery-modal, .masonry').forEach(m => {
          m.querySelectorAll('a[href]').forEach(a => {
            const h = a.getAttribute('href');
            if (h && /\.(jpg|jpeg|png|webp|gif)(\?.*)?$/i.test(h)) found.add(h);
          });
          m.querySelectorAll('img').forEach(img => {
            const s = img.getAttribute('data-original') || img.getAttribute('data-highres') ||
                       img.getAttribute('data-full') || img.getAttribute('data-src') || img.src;
            if (s) found.add(s);
          });
        });
        return JSON.stringify(Array.from(found));
      })()"""
    private fun getTriggerModalJs(sceneId: String): String =
      """(function() {
        try {
          if (window.location.hash) {
            window.dispatchEvent(new HashChangeEvent('hashchange', {
              oldURL: window.location.href.split('#')[0],
              newURL: window.location.href
            }));
          }
          const id = '$sceneId';
          if (id) {
            const triggers = document.querySelectorAll(
              '[data-app-modal-data="' + id + '"], [data-scene-id="' + id + '"], [data-id="' + id + '"], a[href*="' + id + '"], .card.tmb[data-app-modal-data="' + id + '"]'
            );
            for (const t of triggers) {
              t.click();
              return true;
            }
          }
        } catch(e) {}
        return false;
      })()"""
  }

  @SuppressLint("SetJavaScriptEnabled")
  suspend fun scrapeUrl(
    targetUrl: String,
    settings: AppSettings,
    onCrawlProgress: (suspend (pagesScanned: Int, linksFound: Int, currentUrl: String) -> Unit)? = null
  ): ScrapeResult = withContext(Dispatchers.Main) {
    val domain = UrlNormalizer.getDomain(targetUrl)
    val interceptedImages = ConcurrentHashMap.newKeySet<String>()
    var webView: WebView? = null
    try {
      val pageFinishedDeferred = CompletableDeferred<Unit>()
      webView = WebView(context.applicationContext).apply {
        alpha = 0f
        setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
        val webSettings = this.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.databaseEnabled = true
        webSettings.loadWithOverviewMode = true
        webSettings.useWideViewPort = true
        webSettings.userAgentString = DESKTOP_UA
        webSettings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        webSettings.blockNetworkImage = false
        webSettings.cacheMode = WebSettings.LOAD_DEFAULT
        webSettings.mediaPlaybackRequiresUserGesture = false
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(this, true)
        webViewClient = object : WebViewClient() {
          override fun shouldInterceptRequest(
            view: WebView?,
            request: WebResourceRequest?
          ): WebResourceResponse? {
            val reqUrl = request?.url?.toString()
            if (reqUrl != null && !reqUrl.startsWith("data:") && UrlNormalizer.isSupportedImage(reqUrl)) {
              interceptedImages.add(reqUrl)
            }
            return super.shouldInterceptRequest(view, request)
          }
          override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            if (!pageFinishedDeferred.isCompleted) {
              pageFinishedDeferred.complete(Unit)
            }
          }
        }
      }
      webView.loadUrl(targetUrl)
      withTimeoutOrNull(20_000L) {
        pageFinishedDeferred.await()
      }
      delay(1000L)
      val modalSceneId = UrlNormalizer.extractModalSceneId(targetUrl)
      if (!modalSceneId.isNullOrBlank()) {
        evaluateJs(webView, getTriggerModalJs(modalSceneId))
        delay(1500L)
      }
      var depth = 0
      val maxDepth = settings.maxPageDepth
      val scrollTimeoutMs = settings.scrollTimeoutSec * 1000L
      while (depth < maxDepth) {
        depth++
        webView.evaluateJavascript(SCROLL_JS, null)
        val startTime = System.currentTimeMillis()
        var isDone = false
        while (!isDone && (System.currentTimeMillis() - startTime) < scrollTimeoutMs) {
          delay(500L)
          val result = evaluateJs(webView, "window.__done")
          if (result == "true") {
            isDone = true
          }
        }
        if (depth < maxDepth) {
          val clicked = evaluateJs(webView, CLICK_NEXT_JS)
          if (clicked == "true") {
            delay(1500L)
          } else {
            break
          }
        }
      }
      val pageTitle = webView.title ?: domain
      val domImagesJson = evaluateJs(webView, EXTRACT_DOM_IMAGES_JS)
      val domCandidates = mutableListOf<String>()
      try {
        val jsonArray = JSONArray(domImagesJson)
        for (i in 0 until jsonArray.length()) {
          val candidate = jsonArray.optString(i)
          if (candidate.isNotBlank()) {
            domCandidates.add(candidate)
          }
        }
      } catch (_: Exception) {}
      val outerHtml = evaluateJs(webView, "document.documentElement.outerHTML")
      val jsoupCandidates = withContext(Dispatchers.IO) {
        extractWithJsoup(outerHtml, targetUrl)
      }
      val cookies = CookieManager.getInstance().getCookie(targetUrl) ?: ""
      val directModalImages = if (!modalSceneId.isNullOrBlank()) {
        withContext(Dispatchers.IO) {
          fetchDirectModalImages(targetUrl, domain, modalSceneId, cookies)
        }
      } else {
        emptyList()
      }
      val initialCount = (directModalImages + interceptedImages + domCandidates + jsoupCandidates).size
      onCrawlProgress?.invoke(1, initialCount, targetUrl)
      val subpageCandidates = mutableListOf<String>()
      if (settings.maxPageDepth > 1) {
        withContext(Dispatchers.IO) {
          val queue = ArrayDeque<String>()
          val visitedSubpages = mutableSetOf(targetUrl)
          val initialSubpages = extractSubcategoryLinks(outerHtml, targetUrl)
            .filter { it != targetUrl }
          queue.addAll(initialSubpages)
          val maxSubpages = settings.maxPageDepth * 3
          while (queue.isNotEmpty() && visitedSubpages.size < maxSubpages) {
            val subpageUrl = queue.removeFirst()
            if (visitedSubpages.contains(subpageUrl)) continue
            visitedSubpages.add(subpageUrl)
            try {
              val req = Request.Builder()
                .url(subpageUrl)
                .header("User-Agent", DESKTOP_UA)
                .header("Referer", targetUrl)
              if (cookies.isNotBlank()) {
                req.header("Cookie", cookies)
              }
              val resp = okHttpClient.newCall(req.build()).execute()
              if (resp.isSuccessful) {
                val subpageHtml = resp.body?.string() ?: ""
                resp.close()
                val extracted = extractWithJsoup(subpageHtml, subpageUrl)
                for (raw in extracted) {
                  val resolved = UrlNormalizer.resolveUrl(subpageUrl, raw) ?: continue
                  if (UrlNormalizer.isSupportedImage(resolved)) {
                    subpageCandidates.add(resolved)
                  }
                }
                if (visitedSubpages.size < maxSubpages) {
                  val moreLinks = extractSubcategoryLinks(subpageHtml, subpageUrl)
                  for (more in moreLinks) {
                    if (!visitedSubpages.contains(more) && !queue.contains(more)) {
                      queue.add(more)
                    }
                  }
                }
                val currentTotalFound = (directModalImages + interceptedImages + domCandidates + jsoupCandidates + subpageCandidates).size
                onCrawlProgress?.invoke(visitedSubpages.size, currentTotalFound, subpageUrl)
              } else {
                resp.close()
              }
            } catch (_: Exception) {}
          }
        }
      }
      val allRawCandidates = (directModalImages + interceptedImages + domCandidates + jsoupCandidates + subpageCandidates).toSet()
      val resolvedUrls = mutableSetOf<String>()
      for (raw in allRawCandidates) {
        val resolved = UrlNormalizer.resolveUrl(targetUrl, raw) ?: continue
        if (UrlNormalizer.isSupportedImage(resolved)) {
          resolvedUrls.add(resolved)
        }
      }
      val orderedUrls = if (directModalImages.isNotEmpty()) {
        val directResolved = directModalImages.mapNotNull { UrlNormalizer.resolveUrl(targetUrl, it) }
          .filter { UrlNormalizer.isSupportedImage(it) }
        (directResolved + (resolvedUrls - directResolved.toSet())).distinct()
      } else {
        resolvedUrls.toList()
      }
      // Thumbnail behalten + Fullsize-Upgrade parallel erzeugen
      val candidatePairs = withContext(Dispatchers.IO) {
        orderedUrls.map { raw ->
          val full = UrlNormalizer.tryUpgradeThumbnail(raw, okHttpClient, targetUrl)
          ImageCandidate(thumbnailUrl = raw, fullUrl = full)
        }.distinctBy { it.fullUrl }
      }
      ScrapeResult(
        title = if (pageTitle.isBlank()) domain else pageTitle,
        domain = domain,
        imageUrls = candidatePairs.map { it.fullUrl },
        candidates = candidatePairs,
        cookies = cookies
      )
    } finally {
      cleanUpWebView(webView)
    }
  }

  private suspend fun evaluateJs(webView: WebView, script: String): String =
    suspendCancellableCoroutine { cont ->
      webView.evaluateJavascript(script) { result ->
        if (cont.isActive) {
          val cleaned = result?.trim()?.removeSurrounding("\"")?.replace("\\\"", "\"") ?: ""
          cont.resume(cleaned)
        }
      }
    }

  private fun extractWithJsoup(html: String, baseUrl: String): List<String> {
    val results = mutableListOf<String>()
    if (html.isBlank()) return results
    try {
      val doc = Jsoup.parse(html, baseUrl)
      val imageLinks = doc.select("a[href]")
      for (link in imageLinks) {
        val href = link.attr("href")
        val absHref = link.absUrl("href").ifBlank { href }
        if (UrlNormalizer.isSupportedImage(absHref)) {
          results.add(absHref)
        }
      }
      val images = doc.select("img")
      for (img in images) {
        val dataOriginal = img.attr("data-original")
        val dataHighRes = img.attr("data-highres")
        val dataFull = img.attr("data-full")
        val dataZoom = img.attr("data-zoom-image")
        val dataLarge = img.attr("data-large-src")
        val dataSrc = img.attr("data-src")
        val dataLazy = img.attr("data-lazy-src")
        val srcset = img.attr("srcset")
        val src = img.attr("src")
        if (dataOriginal.isNotBlank()) results.add(dataOriginal)
        if (dataHighRes.isNotBlank()) results.add(dataHighRes)
        if (dataFull.isNotBlank()) results.add(dataFull)
        if (dataZoom.isNotBlank()) results.add(dataZoom)
        if (dataLarge.isNotBlank()) results.add(dataLarge)
        if (dataSrc.isNotBlank()) results.add(dataSrc)
        if (dataLazy.isNotBlank()) results.add(dataLazy)
        if (srcset.isNotBlank()) {
          UrlNormalizer.getLargestFromSrcset(srcset, baseUrl)?.let { results.add(it) }
        }
        if (src.isNotBlank()) results.add(src)
      }
      val sources = doc.select("picture source")
      for (source in sources) {
        val srcset = source.attr("srcset")
        if (srcset.isNotBlank()) {
          UrlNormalizer.getLargestFromSrcset(srcset, baseUrl)?.let { results.add(it) }
        }
      }
    } catch (_: Exception) {}
    return results
  }

  private fun extractSubcategoryLinks(html: String, baseUrl: String): List<String> {
    val subpages = mutableListOf<String>()
    if (html.isBlank()) return subpages
    try {
      val doc = Jsoup.parse(html, baseUrl)
      val links = doc.select("a[href]")
      for (link in links) {
        val href = link.absUrl("href").ifBlank { link.attr("href") }
        val resolved = UrlNormalizer.resolveUrl(baseUrl, href) ?: continue
        if (UrlNormalizer.isSameDomainSubpage(baseUrl, resolved)) {
          subpages.add(resolved)
        }
      }
    } catch (_: Exception) {}
    return subpages.distinct()
  }

  private fun cleanUpWebView(webView: WebView?) {
    try {
      webView?.apply {
        stopLoading()
        loadUrl("about:blank")
        clearHistory()
        removeAllViews()
        destroy()
      }
    } catch (_: Exception) {}
  }

  private fun fetchDirectModalImages(
    targetUrl: String,
    domain: String,
    modalSceneId: String,
    cookies: String
  ): List<String> {
    val results = mutableListOf<String>()
    val endpoints = listOf(
      "https://$domain/image-scenes/$modalSceneId/modal",
      "https://$domain/modal/scene/$modalSceneId",
      "https://$domain/api/scene/$modalSceneId",
      "https://$domain/ajax/modal/scene/$modalSceneId",
      "https://www.$domain/image-scenes/$modalSceneId/modal"
    )
    for (ep in endpoints) {
      try {
        val req = Request.Builder()
          .url(ep)
          .header("User-Agent", DESKTOP_UA)
          .header("Referer", targetUrl)
          .header("X-Requested-With", "XMLHttpRequest")
        if (cookies.isNotBlank()) req.header("Cookie", cookies)
        val resp = okHttpClient.newCall(req.build()).execute()
        if (resp.isSuccessful) {
          val body = resp.body?.string() ?: ""
          resp.close()
          if (body.isNotBlank()) {
            val extracted = extractWithJsoup(body, ep)
            for (raw in extracted) {
              val resolved = UrlNormalizer.resolveUrl(targetUrl, raw) ?: continue
              if (UrlNormalizer.isSupportedImage(resolved)) {
                results.add(resolved)
              }
            }
            if (results.isNotEmpty()) break
          }
        } else {
          resp.close()
        }
      } catch (_: Exception) {}
    }
    return results.distinct()
  }
}
