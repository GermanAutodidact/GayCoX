package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface QueueDao {
  @Query("SELECT * FROM queue_items ORDER BY createdAt DESC")
  fun getAllQueueItems(): Flow<List<QueueItem>>

  @Query("SELECT * FROM queue_items WHERE id = :id")
  suspend fun getQueueItemById(id: Long): QueueItem?

  @Query("SELECT * FROM queue_items WHERE status = 'WAITING' ORDER BY createdAt ASC")
  suspend fun getWaitingQueueItems(): List<QueueItem>

  @Query("SELECT * FROM queue_items WHERE status = 'READY_TO_DOWNLOAD' ORDER BY createdAt ASC")
  suspend fun getReadyToDownloadItems(): List<QueueItem>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertQueueItem(item: QueueItem): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertQueueItems(items: List<QueueItem>): List<Long>

  @Update
  suspend fun updateQueueItem(item: QueueItem)

  @Query("UPDATE queue_items SET status = :status, errorMessage = :error WHERE id = :id")
  suspend fun updateStatus(id: Long, status: QueueStatus, error: String? = null)

  @Query("UPDATE queue_items SET status = :status, errorMessage = :error, logReport = :logReport WHERE id = :id")
  suspend fun updateStatusWithLog(id: Long, status: QueueStatus, error: String? = null, logReport: String)

  @Query("UPDATE queue_items SET logReport = :logReport WHERE id = :id")
  suspend fun updateLogReport(id: Long, logReport: String)

  @Query("UPDATE queue_items SET candidateUrlsJson = :candidatesJson WHERE id = :id")
  suspend fun updateCandidateUrls(id: Long, candidatesJson: String)

  @Query("UPDATE queue_items SET progress = :progress, total = :total WHERE id = :id")
  suspend fun updateProgress(id: Long, progress: Int, total: Int)

  @Query("UPDATE queue_items SET progress = :progress, total = :total, logReport = :logReport WHERE id = :id")
  suspend fun updateProgressWithLog(id: Long, progress: Int, total: Int, logReport: String)

  @Query("UPDATE queue_items SET title = :title, domain = :domain WHERE id = :id")
  suspend fun updateMetadata(id: Long, title: String, domain: String)

  @Query("UPDATE queue_items SET status = 'WAITING' WHERE status IN ('SCANNING', 'DOWNLOADING', 'READY_TO_DOWNLOAD')")
  suspend fun resetInterruptedItems()

  @Query("UPDATE queue_items SET status = 'WAITING', errorMessage = NULL, progress = 0, total = 0, logReport = '', candidateUrlsJson = '' WHERE id = :id AND status = 'ERROR'")
  suspend fun retryErrorItem(id: Long)

  @Query("UPDATE queue_items SET status = 'WAITING', errorMessage = NULL, progress = 0, total = 0, logReport = '', candidateUrlsJson = '' WHERE status = 'ERROR'")
  suspend fun retryAllErrorItems()

  @Query("DELETE FROM queue_items WHERE id = :id")
  suspend fun deleteQueueItemById(id: Long)

  @Query("DELETE FROM queue_items WHERE status = 'COMPLETED'")
  suspend fun deleteCompletedItems()

  @Query("DELETE FROM queue_items")
  suspend fun clearAll()

  @Query("SELECT * FROM downloaded_images WHERE queueItemId = :queueItemId ORDER BY id DESC")
  fun getImagesForQueue(queueItemId: Long): Flow<List<DownloadedImage>>

  @Query("SELECT * FROM downloaded_images WHERE queueItemId = :queueItemId ORDER BY id DESC")
  suspend fun getImagesForQueueSync(queueItemId: Long): List<DownloadedImage>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertImage(image: DownloadedImage): Long
}
