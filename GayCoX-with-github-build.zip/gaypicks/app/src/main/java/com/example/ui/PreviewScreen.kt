package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Deselect
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import com.example.data.PreviewCandidate
import com.example.ui.theme.BerryPrimary
import com.example.ui.theme.HeartRed
import com.example.ui.theme.MatteBorder
import com.example.ui.theme.MatteCardBg
import com.example.ui.theme.MattePinkSurface
import com.example.ui.theme.TextDeepCharcoal
import com.example.ui.theme.TextMutedPlum
import com.example.ui.theme.TextPlumMedium
import com.example.ui.theme.TextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PreviewScreen(
  title: String,
  domain: String,
  candidates: List<PreviewCandidate>,
  onToggleCandidate: (String) -> Unit,
  onSelectAll: () -> Unit,
  onDeselectAll: () -> Unit,
  onConfirmDownload: (List<PreviewCandidate>) -> Unit,
  onNavigateBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler {
    onNavigateBack()
  }

  var inspectedImageUrl by remember { mutableStateOf<String?>(null) }
  val selectedCount = candidates.count { it.isSelected }

  MatteHeartBackground(modifier = modifier) {
    Scaffold(
      modifier = Modifier.testTag("preview_screen"),
      containerColor = Color.Transparent,
      topBar = {
        TopAppBar(
          title = {
            Column {
              Text(
                text = "Gefundene Bilder prüfen",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextDeepCharcoal
              )
              Text(
                text = domain.ifBlank { title },
                style = MaterialTheme.typography.bodySmall,
                color = TextPlumMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
          },
          navigationIcon = {
            IconButton(
              onClick = onNavigateBack,
              modifier = Modifier.testTag("preview_back_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Zurück",
                tint = TextDeepCharcoal
              )
            }
          },
          actions = {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MatteCardBg,
              border = BorderStroke(1.dp, MatteBorder),
              modifier = Modifier.padding(end = 12.dp)
            ) {
              Text(
                text = "$selectedCount / ${candidates.size}",
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (selectedCount > 0) HeartRed else TextMutedPlum,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
              )
            }
          },
          colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )
      },
      bottomBar = {
        Surface(
          color = MatteCardBg,
          border = BorderStroke(1.dp, MatteBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(
                text = "$selectedCount Bilder gewählt",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextDeepCharcoal
              )
              Text(
                text = "Format: JPG (≤ 300 KB)",
                style = MaterialTheme.typography.labelSmall,
                color = TextPlumMedium
              )
            }

            Button(
              onClick = {
                val selectedList = candidates.filter { it.isSelected }
                onConfirmDownload(selectedList)
              },
              enabled = selectedCount > 0,
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = HeartRed,
                contentColor = TextWhite,
                disabledContainerColor = MattePinkSurface,
                disabledContentColor = TextMutedPlum
              ),
              modifier = Modifier.testTag("confirm_download_button")
            ) {
              Icon(
                imageVector = Icons.Default.Download,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Herunterladen ($selectedCount)",
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    ) { innerPadding ->
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        // Toolbar: Select All / Deselect All
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          FilledTonalButton(
            onClick = onSelectAll,
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
              containerColor = MatteCardBg,
              contentColor = TextPlumMedium
            ),
            border = BorderStroke(1.dp, MatteBorder),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            modifier = Modifier.height(34.dp)
          ) {
            Icon(
              imageVector = Icons.Default.SelectAll,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
              tint = HeartRed
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Alle", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          }

          FilledTonalButton(
            onClick = onDeselectAll,
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
              containerColor = MatteCardBg,
              contentColor = TextPlumMedium
            ),
            border = BorderStroke(1.dp, MatteBorder),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            modifier = Modifier.height(34.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Deselect,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
              tint = TextMutedPlum
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Keine", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          }

          Spacer(modifier = Modifier.weight(1f))
          Text(
            text = "Tippen zum Vergrößern",
            style = MaterialTheme.typography.labelSmall,
            color = TextPlumMedium
          )
        }

        // Candidates Grid
        LazyVerticalGrid(
          columns = GridCells.Fixed(3),
          contentPadding = PaddingValues(12.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxSize()
        ) {
          items(candidates, key = { it.id }) { candidate ->
            PreviewCandidateCard(
              candidate = candidate,
              onToggle = { onToggleCandidate(candidate.id) },
              onInspect = { inspectedImageUrl = candidate.originalUrl }
            )
          }
        }
      }
    }
  }

  // Full Screen Image Inspection Dialog
  inspectedImageUrl?.let { url ->
    ImageViewerDialog(
      localUri = url,
      fileName = "Vorschau",
      onDismiss = { inspectedImageUrl = null }
    )
  }
}

@Composable
private fun PreviewCandidateCard(
  candidate: PreviewCandidate,
  onToggle: () -> Unit,
  onInspect: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = MatteCardBg,
    border = BorderStroke(
      width = if (candidate.isSelected) 2.dp else 1.dp,
      color = if (candidate.isSelected) HeartRed else MatteBorder
    ),
    modifier = modifier
      .aspectRatio(1f)
      .clip(RoundedCornerShape(10.dp))
      .clickable { onInspect() }
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      SubcomposeAsyncImage(
        model = candidate.thumbnailUrl,
        contentDescription = "Bild-Kandidat",
        contentScale = ContentScale.Crop,
        loading = {
          Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
          ) {
            CircularProgressIndicator(
              modifier = Modifier.size(20.dp),
              strokeWidth = 2.dp,
              color = BerryPrimary
            )
          }
        },
        modifier = Modifier.fillMaxSize()
      )

      // Top-right selection checkbox overlay
      Box(
        modifier = Modifier
          .align(Alignment.TopEnd)
          .padding(4.dp)
          .size(26.dp)
          .clip(CircleShape)
          .background(
            if (candidate.isSelected) HeartRed else Color.Black.copy(alpha = 0.6f)
          )
          .clickable { onToggle() },
        contentAlignment = Alignment.Center
      ) {
        if (candidate.isSelected) {
          Icon(
            imageVector = Icons.Default.Check,
            contentDescription = "Ausgewählt",
            tint = TextWhite,
            modifier = Modifier.size(16.dp)
          )
        }
      }

      // Bottom gradient with dimensions if available
      if (candidate.width > 0 && candidate.height > 0) {
        Box(
          modifier = Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .background(
              Brush.verticalGradient(
                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
              )
            )
            .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
          Text(
            text = "${candidate.width}×${candidate.height}",
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            color = TextWhite,
            maxLines = 1
          )
        }
      }
    }
  }
}
