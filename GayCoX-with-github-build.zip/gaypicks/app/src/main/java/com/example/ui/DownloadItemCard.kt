package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.DownloadedImage
import com.example.data.QueueItem
import com.example.data.QueueStatus
import com.example.ui.theme.BerryPrimary
import com.example.ui.theme.HeartRed
import com.example.ui.theme.MatteBorder
import com.example.ui.theme.MatteBorderSubtle
import com.example.ui.theme.MatteCardBg
import com.example.ui.theme.MattePinkSurface
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.TextDeepCharcoal
import com.example.ui.theme.TextMutedPlum
import com.example.ui.theme.TextPlumMedium
import com.example.ui.theme.TextWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadItemCard(
  item: QueueItem,
  images: List<DownloadedImage>,
  isExpanded: Boolean,
  onCardClick: () -> Unit,
  onDismiss: () -> Unit,
  onOpenPreview: ((QueueItem) -> Unit)? = null,
  onShowLog: ((QueueItem) -> Unit)? = null,
  onRetry: ((QueueItem) -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  val dismissState = rememberSwipeToDismissBoxState(
    confirmValueChange = { value ->
      if (value == SwipeToDismissBoxValue.EndToStart || value == SwipeToDismissBoxValue.StartToEnd) {
        onDismiss()
        true
      } else {
        false
      }
    }
  )

  SwipeToDismissBox(
    state = dismissState,
    modifier = modifier.testTag("download_card_${item.id}"),
    backgroundContent = {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .clip(RoundedCornerShape(18.dp))
          .background(Color(0xFFFFEBEE))
          .border(1.dp, StatusError.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
          .padding(horizontal = 24.dp),
        contentAlignment = Alignment.CenterEnd
      ) {
        Icon(
          imageVector = Icons.Default.DeleteOutline,
          contentDescription = stringResource(R.string.delete_item),
          tint = StatusError
        )
      }
    },
    content = {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(18.dp))
          .clickable { onCardClick() },
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(
          width = 1.dp,
          color = when (item.status) {
            QueueStatus.DOWNLOADING, QueueStatus.SCANNING -> HeartRed.copy(alpha = 0.6f)
            QueueStatus.COMPLETED -> StatusSuccess.copy(alpha = 0.5f)
            QueueStatus.ERROR -> StatusError.copy(alpha = 0.5f)
            else -> MatteBorder
          }
        ),
        colors = CardDefaults.cardColors(
          containerColor = MatteCardBg
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          // Top Row: Domain / Title & Status Chip
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              modifier = Modifier.weight(1f),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = MattePinkSurface,
                border = BorderStroke(1.dp, MatteBorder),
                modifier = Modifier.size(38.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = null,
                    tint = BerryPrimary,
                    modifier = Modifier.size(20.dp)
                  )
                }
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = item.title.ifBlank { item.domain.ifBlank { item.url } },
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = TextDeepCharcoal,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
                Text(
                  text = if (item.domain.isNotBlank()) item.domain else item.url,
                  style = MaterialTheme.typography.bodySmall,
                  color = TextPlumMedium,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
              }
            }
            Spacer(modifier = Modifier.width(8.dp))
            StatusChip(status = item.status, errorMessage = item.errorMessage)

            val rotation by animateFloatAsState(
              targetValue = if (isExpanded) 180f else 0f,
              label = "expand_rotation"
            )
            Icon(
              imageVector = Icons.Default.KeyboardArrowDown,
              contentDescription = "Aufklappen",
              modifier = Modifier
                .size(26.dp)
                .rotate(rotation)
                .padding(start = 6.dp),
              tint = TextPlumMedium
            )
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Progress Text & Metrics
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = when (item.status) {
                QueueStatus.WAITING -> stringResource(R.string.status_waiting)
                QueueStatus.SCANNING -> {
                  if (item.total > 0) {
                    "Phase 1: Durchsuche Website (${item.progress} Seiten gescannt • ${item.total} Bild-Links gesammelt)"
                  } else {
                    "Phase 1: Durchsuche Website & Unterseiten nach Bildern..."
                  }
                }
                QueueStatus.AWAITING_SELECTION -> "✓ ${item.total} Bilder gefunden – bitte in der Vorschau auswählen"
                QueueStatus.READY_TO_DOWNLOAD -> "Auswahl bestätigt – starte Download…"
                QueueStatus.DOWNLOADING -> "Phase 2: Lade Bilder herunter (${item.progress}/${item.total}) • JPG ≤ 300 KB"
                QueueStatus.COMPLETED -> "Erfolgreich abgeschlossen (${item.total} Bilder als JPG)"
                QueueStatus.ERROR -> "${stringResource(R.string.status_error)}: ${item.errorMessage ?: ""}"
              },
              style = MaterialTheme.typography.bodySmall,
              color = when (item.status) {
                QueueStatus.ERROR -> StatusError
                QueueStatus.DOWNLOADING, QueueStatus.SCANNING, QueueStatus.READY_TO_DOWNLOAD -> HeartRed
                QueueStatus.AWAITING_SELECTION -> HeartRed
                QueueStatus.COMPLETED -> StatusSuccess
                else -> TextMutedPlum
              },
              fontWeight = if (item.status == QueueStatus.DOWNLOADING || item.status == QueueStatus.SCANNING || item.status == QueueStatus.AWAITING_SELECTION) FontWeight.SemiBold else FontWeight.Normal,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.weight(1f)
            )

            if (item.total > 0 || item.progress > 0) {
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MattePinkSurface,
                border = BorderStroke(1.dp, MatteBorderSubtle)
              ) {
                Text(
                  text = if (item.status == QueueStatus.SCANNING) {
                    "${item.total} Links"
                  } else {
                    "${item.progress} / ${item.total}"
                  },
                  fontFamily = FontFamily.Monospace,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (item.status == QueueStatus.COMPLETED) StatusSuccess else TextDeepCharcoal,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // High-Tech Progress Bar
          val progressRatio = if (item.total > 0) {
            (item.progress.toFloat() / item.total.toFloat()).coerceIn(0f, 1f)
          } else 0f

          if (item.status == QueueStatus.SCANNING) {
            LinearProgressIndicator(
              modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
              color = HeartRed,
              trackColor = MattePinkSurface
            )
          } else {
            LinearProgressIndicator(
              progress = { progressRatio },
              modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
              color = when (item.status) {
                QueueStatus.ERROR -> StatusError
                QueueStatus.COMPLETED -> StatusSuccess
                else -> HeartRed
              },
              trackColor = MattePinkSurface
            )
          }

          // Quick Action Chips: Preview Candidates & Error/Scrape Log
          if (item.candidateUrlsJson.isNotBlank() || item.logReport.isNotBlank() || item.status == QueueStatus.ERROR || item.total > 0) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              if (item.candidateUrlsJson.isNotBlank() || item.total > 0 || item.status == QueueStatus.AWAITING_SELECTION) {
                val needsSelection = item.status == QueueStatus.AWAITING_SELECTION
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = if (needsSelection) HeartRed.copy(alpha = 0.15f) else MattePinkSurface,
                  border = BorderStroke(1.dp, HeartRed.copy(alpha = if (needsSelection) 0.9f else 0.6f)),
                  modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onOpenPreview?.invoke(item) }
                    .testTag("preview_candidates_button_${item.id}")
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                      imageVector = Icons.Default.PhotoLibrary,
                      contentDescription = null,
                      modifier = Modifier.size(15.dp),
                      tint = HeartRed
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = when {
                        needsSelection && item.total > 0 -> "Bilder auswählen (${item.total})"
                        item.total > 0 -> "Vorschau (${item.total} Bilder)"
                        else -> "Vorschau öffnen"
                      },
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = HeartRed
                    )
                  }
                }
              }

              if (item.logReport.isNotBlank() || item.status == QueueStatus.ERROR) {
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = MattePinkSurface,
                  border = BorderStroke(
                    1.dp,
                    if (item.status == QueueStatus.ERROR) StatusError.copy(alpha = 0.6f) else MatteBorderSubtle
                  ),
                  modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onShowLog?.invoke(item) }
                    .testTag("show_log_button_${item.id}")
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                      imageVector = Icons.Default.Description,
                      contentDescription = null,
                      modifier = Modifier.size(15.dp),
                      tint = if (item.status == QueueStatus.ERROR) StatusError else TextPlumMedium
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "Log / Fehlerbericht",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.SemiBold,
                      color = if (item.status == QueueStatus.ERROR) StatusError else TextPlumMedium
                    )
                  }
                }
              }

              if (item.status == QueueStatus.ERROR && onRetry != null) {
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = HeartRed.copy(alpha = 0.12f),
                  border = BorderStroke(1.dp, HeartRed.copy(alpha = 0.5f)),
                  modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onRetry.invoke(item) }
                    .testTag("retry_button_${item.id}")
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                      imageVector = Icons.Default.Sync,
                      contentDescription = null,
                      modifier = Modifier.size(15.dp),
                      tint = HeartRed
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "Erneut versuchen",
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      color = HeartRed
                    )
                  }
                }
              }
            }
          }

          // Expandable Thumbnail Grid
          AnimatedVisibility(visible = isExpanded) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(top = 14.dp)
            ) {
              if (images.isEmpty()) {
                Surface(
                  shape = RoundedCornerShape(12.dp),
                  color = MattePinkSurface,
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text(
                    text = if (item.status == QueueStatus.WAITING) {
                      "Start drücken, um den Batch-Download für diese URL zu starten."
                    } else {
                      "Noch keine Bilder fertiggestellt."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMutedPlum,
                    modifier = Modifier.padding(14.dp)
                  )
                }
              } else {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = "Vorschau (${images.size} heruntergeladen)",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextDeepCharcoal
                  )
                  Text(
                    text = "Tippen zum Vergrößern",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextPlumMedium
                  )
                }
                LazyVerticalGrid(
                  columns = GridCells.Adaptive(minSize = 75.dp),
                  contentPadding = PaddingValues(2.dp),
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  verticalArrangement = Arrangement.spacedBy(8.dp),
                  modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 240.dp)
                ) {
                  items(images, key = { it.id }) { image ->
                    AsyncImage(
                      model = image.localUri,
                      contentDescription = image.fileName,
                      contentScale = ContentScale.Crop,
                      modifier = Modifier
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, MatteBorder, RoundedCornerShape(12.dp))
                        .background(MattePinkSurface)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  )
}

@Composable
fun StatusChip(
  status: QueueStatus,
  errorMessage: String?,
  modifier: Modifier = Modifier
) {
  val infiniteTransition = rememberInfiniteTransition(label = "pulse")
  val pulseAlpha by infiniteTransition.animateFloat(
    initialValue = 0.4f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(800, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulseAlpha"
  )

  val (bgColor, borderColor, contentColor, icon, text) = when (status) {
    QueueStatus.WAITING -> Quint(
      Color(0x207D4E64),
      TextMutedPlum.copy(alpha = 0.5f),
      TextPlumMedium,
      Icons.Default.HourglassEmpty,
      stringResource(R.string.status_waiting)
    )
    QueueStatus.SCANNING -> Quint(
      Color(0x25E53935),
      HeartRed.copy(alpha = pulseAlpha),
      HeartRed,
      Icons.Default.Sync,
      stringResource(R.string.status_scanning)
    )
    QueueStatus.AWAITING_SELECTION -> Quint(
      Color(0x25E53935),
      HeartRed.copy(alpha = 0.7f),
      HeartRed,
      Icons.Default.PhotoLibrary,
      "Auswahl"
    )
    QueueStatus.READY_TO_DOWNLOAD -> Quint(
      Color(0x25E53935),
      HeartRed.copy(alpha = pulseAlpha),
      HeartRed,
      Icons.Default.Sync,
      "Bereit"
    )
    QueueStatus.DOWNLOADING -> Quint(
      Color(0x25E53935),
      HeartRed.copy(alpha = pulseAlpha),
      HeartRed,
      Icons.Default.Sync,
      stringResource(R.string.status_downloading)
    )
    QueueStatus.COMPLETED -> Quint(
      Color(0x2016A34A),
      StatusSuccess.copy(alpha = 0.5f),
      StatusSuccess,
      Icons.Default.CheckCircle,
      stringResource(R.string.status_completed)
    )
    QueueStatus.ERROR -> Quint(
      Color(0x20E11D48),
      StatusError.copy(alpha = 0.5f),
      StatusError,
      Icons.Default.ErrorOutline,
      stringResource(R.string.status_error)
    )
  }

  Surface(
    modifier = modifier,
    shape = CircleShape,
    color = bgColor,
    border = BorderStroke(1.dp, borderColor)
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      val rotation by animateFloatAsState(
        targetValue = if (status == QueueStatus.SCANNING || status == QueueStatus.DOWNLOADING) 360f else 0f,
        animationSpec = infiniteRepeatable(
          animation = tween(1200, easing = LinearEasing),
          repeatMode = RepeatMode.Restart
        ),
        label = "chip_spin"
      )
      Icon(
        imageVector = icon,
        contentDescription = null,
        modifier = Modifier
          .size(13.dp)
          .then(
            if (status == QueueStatus.SCANNING || status == QueueStatus.DOWNLOADING) {
              Modifier.rotate(rotation)
            } else Modifier
          ),
        tint = contentColor
      )
      Spacer(modifier = Modifier.width(5.dp))
      Text(
        text = text,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        color = contentColor
      )
    }
  }
}

private data class Quint<A, B, C, D, E>(
  val first: A,
  val second: B,
  val third: C,
  val fourth: D,
  val fifth: E
)
