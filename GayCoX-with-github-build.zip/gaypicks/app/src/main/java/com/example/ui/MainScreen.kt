package com.example.ui

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Queue
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Web
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.DownloadedImage
import com.example.data.QueueItem
import com.example.data.QueueStatus
import com.example.data.SessionImage
import com.example.data.SessionWithImages
import com.example.ui.theme.BerryPrimary
import com.example.ui.theme.HeartRed
import com.example.ui.theme.MatteBorder
import com.example.ui.theme.MatteBorderSubtle
import com.example.ui.theme.MatteCardBg
import com.example.ui.theme.MattePinkSurface
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.TextDeepCharcoal
import com.example.ui.theme.TextMutedPlum
import com.example.ui.theme.TextPlumMedium
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.flow.SharedFlow

enum class MainTab {
  QUEUE,
  HISTORY
}

data class ImageViewerState(
  val localUri: String,
  val fileName: String,
  val width: Int = 0,
  val height: Int = 0,
  val fileSize: Long = 0L
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
  uiState: MainUiState,
  inputText: String,
  snackbarMessage: SharedFlow<String>,
  onInputTextChanged: (String) -> Unit,
  onAddUrlsToQueue: () -> Unit,
  onImportFromClipboard: () -> Unit,
  onImportFromFile: (Uri) -> Unit,
  onImportDetectedClipboard: () -> Unit,
  onDismissClipboardBanner: () -> Unit,
  onStartAll: () -> Unit,
  onClearCompleted: () -> Unit,
  onClearAll: () -> Unit,
  onDeleteItem: (Long) -> Unit,
  onToggleItemExpansion: (Long) -> Unit,
  onDeleteSession: (Long) -> Unit,
  onClearAllHistory: () -> Unit,
  onNavigateToSettings: () -> Unit,
  onOpenPreviewFromItem: (QueueItem) -> Unit = {},
  onRetryItem: (Long) -> Unit = {},
  modifier: Modifier = Modifier
) {
  val snackbarHostState = remember { SnackbarHostState() }
  var showHelpDialog by remember { mutableStateOf(false) }
  var selectedTab by remember { mutableStateOf(MainTab.QUEUE) }
  var viewingImage by remember { mutableStateOf<ImageViewerState?>(null) }
  var showClearHistoryDialog by remember { mutableStateOf(false) }
  var selectedLogItem by remember { mutableStateOf<QueueItem?>(null) }

  val notificationPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { _ -> }

  LaunchedEffect(Unit) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
  }

  LaunchedEffect(snackbarMessage) {
    snackbarMessage.collect { message ->
      snackbarHostState.showSnackbar(message)
    }
  }

  viewingImage?.let { imageState ->
    ImageViewerDialog(
      localUri = imageState.localUri,
      fileName = imageState.fileName,
      width = imageState.width,
      height = imageState.height,
      fileSize = imageState.fileSize,
      onDismiss = { viewingImage = null }
    )
  }

  if (showClearHistoryDialog) {
    AlertDialog(
      onDismissRequest = { showClearHistoryDialog = false },
      containerColor = MatteCardBg,
      shape = RoundedCornerShape(22.dp),
      title = {
        Text(
          text = "Download-Historie leeren?",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = TextDeepCharcoal
        )
      },
      text = {
        Text(
          text = "Möchtest du alle vergangenen Sitzungseinträge aus der Datenbank entfernen? Die heruntergeladenen Bilddateien im Speicher bleiben dabei erhalten.",
          style = MaterialTheme.typography.bodyMedium,
          color = TextPlumMedium
        )
      },
      confirmButton = {
        Button(
          onClick = {
            showClearHistoryDialog = false
            onClearAllHistory()
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = StatusError,
            contentColor = TextWhite
          ),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text("Ja, leeren", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        FilledTonalButton(
          onClick = { showClearHistoryDialog = false },
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = MattePinkSurface,
            contentColor = TextPlumMedium
          )
        ) {
          Text("Abbrechen")
        }
      }
    )
  }

  if (showHelpDialog) {
    AlertDialog(
      onDismissRequest = { showHelpDialog = false },
      containerColor = MatteCardBg,
      shape = RoundedCornerShape(22.dp),
      icon = {
        Box(
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(Color(0x20E53935)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Web,
            contentDescription = null,
            tint = HeartRed,
            modifier = Modifier.size(24.dp)
          )
        }
      },
      title = {
        Text(
          text = stringResource(R.string.browser_import_dialog_title),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = TextDeepCharcoal,
          textAlign = TextAlign.Center
        )
      },
      text = {
        Text(
          text = stringResource(R.string.browser_import_dialog_content),
          style = MaterialTheme.typography.bodyMedium,
          color = TextPlumMedium,
          lineHeight = 22.sp
        )
      },
      confirmButton = {
        Button(
          onClick = { showHelpDialog = false },
          colors = ButtonDefaults.buttonColors(
            containerColor = HeartRed,
            contentColor = TextWhite
          ),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text(text = stringResource(R.string.dialog_understood), fontWeight = FontWeight.Bold)
        }
      }
    )
  }

  MatteHeartBackground(modifier = modifier) {
    Scaffold(
      modifier = Modifier.testTag("main_screen"),
      containerColor = Color.Transparent,
      snackbarHost = { SnackbarHost(snackbarHostState) },
      topBar = {
        TopAppBar(
          title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .background(
                    Brush.linearGradient(
                      colors = listOf(HeartRed, BerryPrimary)
                    )
                  ),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.Favorite,
                  contentDescription = null,
                  tint = TextWhite,
                  modifier = Modifier.size(22.dp)
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "GayCoX",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextDeepCharcoal,
                    letterSpacing = 0.5.sp
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = null,
                    tint = HeartRed,
                    modifier = Modifier.size(15.dp)
                  )
                }
                Text(
                  text = "SMART BULK SCRAPER & DOWNLOADER",
                  style = MaterialTheme.typography.labelSmall,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 1.2.sp,
                  color = BerryPrimary
                )
              }
            }
          },
          actions = {
            IconButton(
              onClick = { showHelpDialog = true },
              modifier = Modifier.testTag("help_guide_button")
            ) {
              Icon(
                imageVector = Icons.Default.HelpOutline,
                contentDescription = "Tabs-Anleitung",
                tint = TextDeepCharcoal
              )
            }
            IconButton(
              onClick = onNavigateToSettings,
              modifier = Modifier.testTag("settings_button")
            ) {
              Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = stringResource(R.string.settings),
                tint = TextDeepCharcoal
              )
            }
          },
          colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color.Transparent
          )
        )
      }
    ) { innerPadding ->
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
          .padding(horizontal = 16.dp)
      ) {
        // Modern Navigation Tabs: [ Queue (X) ] and [ Historie (Y) ]
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MatteCardBg)
            .border(1.dp, MatteBorder, RoundedCornerShape(14.dp))
            .padding(4.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          val isQueueActive = selectedTab == MainTab.QUEUE
          Box(
            modifier = Modifier
              .weight(1f)
              .height(40.dp)
              .clip(RoundedCornerShape(11.dp))
              .background(
                if (isQueueActive) Brush.horizontalGradient(
                  colors = listOf(HeartRed, BerryPrimary)
                ) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
              )
              .clickable { selectedTab = MainTab.QUEUE }
              .testTag("tab_queue"),
            contentAlignment = Alignment.Center
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Queue,
                contentDescription = null,
                modifier = Modifier.size(17.dp),
                tint = if (isQueueActive) TextWhite else TextPlumMedium
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Queue (${uiState.queueItems.size})",
                fontWeight = if (isQueueActive) FontWeight.ExtraBold else FontWeight.SemiBold,
                fontSize = 13.sp,
                color = if (isQueueActive) TextWhite else TextPlumMedium
              )
            }
          }

          val isHistoryActive = selectedTab == MainTab.HISTORY
          Box(
            modifier = Modifier
              .weight(1f)
              .height(40.dp)
              .clip(RoundedCornerShape(11.dp))
              .background(
                if (isHistoryActive) Brush.horizontalGradient(
                  colors = listOf(HeartRed, BerryPrimary)
                ) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
              )
              .clickable { selectedTab = MainTab.HISTORY }
              .testTag("tab_history"),
            contentAlignment = Alignment.Center
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.History,
                contentDescription = null,
                modifier = Modifier.size(17.dp),
                tint = if (isHistoryActive) TextWhite else TextPlumMedium
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Historie (${uiState.historySessions.size})",
                fontWeight = if (isHistoryActive) FontWeight.ExtraBold else FontWeight.SemiBold,
                fontSize = 13.sp,
                color = if (isHistoryActive) TextWhite else TextPlumMedium
              )
            }
          }
        }

        // Tab Content
        if (selectedTab == MainTab.QUEUE) {
          QueueTabContent(
            uiState = uiState,
            inputText = inputText,
            onInputTextChanged = onInputTextChanged,
            onAddUrlsToQueue = onAddUrlsToQueue,
            onImportFromClipboard = onImportFromClipboard,
            onImportFromFile = onImportFromFile,
            onImportDetectedClipboard = onImportDetectedClipboard,
            onDismissClipboardBanner = onDismissClipboardBanner,
            onStartAll = onStartAll,
            onClearCompleted = onClearCompleted,
            onClearAll = onClearAll,
            onDeleteItem = onDeleteItem,
            onToggleItemExpansion = onToggleItemExpansion,
            onOpenPreview = onOpenPreviewFromItem,
            onShowLog = { selectedLogItem = it },
            onRetryItem = onRetryItem,
            onImageClick = { img: DownloadedImage ->
              viewingImage = ImageViewerState(
                localUri = img.localUri,
                fileName = img.fileName,
                width = img.width,
                height = img.height,
                fileSize = img.fileSize
              )
            }
          )
        } else {
          HistoryTabContent(
            sessions = uiState.historySessions,
            onDeleteSession = onDeleteSession,
            onClearAllHistory = { showClearHistoryDialog = true },
            onImageClick = { sessionImg: SessionImage ->
              viewingImage = ImageViewerState(
                localUri = sessionImg.localUri,
                fileName = sessionImg.fileName,
                width = sessionImg.width,
                height = sessionImg.height,
                fileSize = sessionImg.fileSize
              )
            }
          )
        }
      }
    }
  }

  selectedLogItem?.let { logItem ->
    ScrapeLogDialog(
      item = logItem,
      onDismiss = { selectedLogItem = null }
    )
  }
}

@Composable
fun QueueTabContent(
  uiState: MainUiState,
  inputText: String,
  onInputTextChanged: (String) -> Unit,
  onAddUrlsToQueue: () -> Unit,
  onImportFromClipboard: () -> Unit,
  onImportFromFile: (Uri) -> Unit,
  onImportDetectedClipboard: () -> Unit,
  onDismissClipboardBanner: () -> Unit,
  onStartAll: () -> Unit,
  onClearCompleted: () -> Unit,
  onClearAll: () -> Unit,
  onDeleteItem: (Long) -> Unit,
  onToggleItemExpansion: (Long) -> Unit,
  onOpenPreview: (QueueItem) -> Unit,
  onShowLog: (QueueItem) -> Unit,
  onRetryItem: (Long) -> Unit = {},
  onImageClick: (DownloadedImage) -> Unit
) {
  val filePickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument()
  ) { uri: Uri? ->
    if (uri != null) {
      onImportFromFile(uri)
    }
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    shape = RoundedCornerShape(20.dp),
    border = BorderStroke(1.dp, MatteBorder),
    colors = CardDefaults.cardColors(
      containerColor = MatteCardBg
    )
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      AnimatedVisibility(
        visible = uiState.detectedClipboardCount > 0,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically()
      ) {
        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .testTag("clipboard_detected_banner"),
          shape = RoundedCornerShape(12.dp),
          color = MattePinkSurface,
          border = BorderStroke(1.dp, MatteBorder)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Icon(
                imageVector = Icons.Default.Favorite,
                contentDescription = null,
                tint = HeartRed,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "${uiState.detectedClipboardCount} URLs in Zwischenablage erkannt",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = TextDeepCharcoal
              )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
              Button(
                onClick = onImportDetectedClipboard,
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = BerryPrimary,
                  contentColor = TextWhite
                ),
                modifier = Modifier.height(30.dp)
              ) {
                Text(
                  text = stringResource(R.string.import_now),
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
              Spacer(modifier = Modifier.width(4.dp))
              IconButton(
                onClick = onDismissClipboardBanner,
                modifier = Modifier.size(28.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Close,
                  contentDescription = stringResource(R.string.dismiss),
                  tint = TextMutedPlum,
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          }
        }
      }

      OutlinedTextField(
        value = inputText,
        onValueChange = onInputTextChanged,
        modifier = Modifier
          .fillMaxWidth()
          .height(95.dp)
          .testTag("url_input_field"),
        placeholder = {
          Text(
            text = stringResource(R.string.input_placeholder),
            style = MaterialTheme.typography.bodyMedium,
            color = TextMutedPlum
          )
        },
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = BerryPrimary,
          unfocusedBorderColor = MatteBorder,
          focusedContainerColor = MattePinkSurface,
          unfocusedContainerColor = MattePinkSurface,
          focusedTextColor = TextDeepCharcoal,
          unfocusedTextColor = TextDeepCharcoal,
          cursorColor = BerryPrimary
        )
      )

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MattePinkSurface,
          border = BorderStroke(1.dp, MatteBorderSubtle)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(HeartRed)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Unterkategorien-Scan aktiv • JPG-Konvertierung (100 KB – max. 300 KB)",
              style = MaterialTheme.typography.labelSmall,
              fontSize = 11.sp,
              color = TextPlumMedium
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilledTonalButton(
            onClick = onImportFromClipboard,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
              containerColor = MattePinkSurface,
              contentColor = TextDeepCharcoal
            ),
            border = BorderStroke(1.dp, MatteBorder),
            modifier = Modifier.height(36.dp)
          ) {
            Icon(
              imageVector = Icons.Default.ContentPaste,
              contentDescription = null,
              modifier = Modifier.size(15.dp),
              tint = BerryPrimary
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Einfügen", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          }

          FilledTonalButton(
            onClick = {
              filePickerLauncher.launch(
                arrayOf(
                  "text/*",
                  "text/html",
                  "text/plain",
                  "application/octet-stream",
                  "*/*"
                )
              )
            },
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
              containerColor = MattePinkSurface,
              contentColor = TextDeepCharcoal
            ),
            border = BorderStroke(1.dp, MatteBorder),
            modifier = Modifier.height(36.dp)
          ) {
            Icon(
              imageVector = Icons.Default.FileOpen,
              contentDescription = null,
              modifier = Modifier.size(15.dp),
              tint = BerryPrimary
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Datei / Tabs", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          }
        }

        Button(
          onClick = onAddUrlsToQueue,
          enabled = inputText.isNotBlank(),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = BerryPrimary,
            contentColor = TextWhite,
            disabledContainerColor = MattePinkSurface,
            disabledContentColor = TextMutedPlum
          ),
          modifier = Modifier
            .height(36.dp)
            .testTag("add_to_queue_button")
        ) {
          Icon(
            imageVector = Icons.Default.Add,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = stringResource(R.string.add_to_queue),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(top = 10.dp, bottom = 8.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier
          .size(8.dp)
          .clip(CircleShape)
          .background(
            if (uiState.queueItems.any { it.status == QueueStatus.DOWNLOADING || it.status == QueueStatus.SCANNING }) {
              HeartRed
            } else if (uiState.queueItems.isNotEmpty()) {
              StatusSuccess
            } else {
              TextMutedPlum
            }
          )
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "WARTESCHLANGE",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = TextDeepCharcoal,
        letterSpacing = 1.sp
      )
      Spacer(modifier = Modifier.width(8.dp))
      Surface(
        shape = RoundedCornerShape(6.dp),
        color = MattePinkSurface,
        border = BorderStroke(1.dp, MatteBorder)
      ) {
        Text(
          text = "${uiState.queueItems.size}",
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = TextDeepCharcoal,
          modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
        )
      }
    }

    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      if (uiState.queueItems.isNotEmpty()) {
        Button(
          onClick = onStartAll,
          contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = HeartRed,
            contentColor = TextWhite
          ),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .height(34.dp)
            .testTag("start_all_button")
        ) {
          Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = stringResource(R.string.start_all),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }

        val hasCompleted = uiState.queueItems.any { it.status == QueueStatus.COMPLETED }
        if (hasCompleted) {
          IconButton(
            onClick = onClearCompleted,
            modifier = Modifier
              .size(34.dp)
              .testTag("clear_completed_button")
          ) {
            Icon(
              imageVector = Icons.Default.DeleteSweep,
              contentDescription = stringResource(R.string.clear_completed),
              tint = TextPlumMedium,
              modifier = Modifier.size(20.dp)
            )
          }
        }

        IconButton(
          onClick = onClearAll,
          modifier = Modifier
            .size(34.dp)
            .testTag("clear_all_button")
        ) {
          Icon(
            imageVector = Icons.Default.ClearAll,
            contentDescription = stringResource(R.string.clear_all),
            tint = TextMutedPlum,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }

  if (uiState.queueItems.isEmpty()) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(24.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Box(
          modifier = Modifier
            .size(76.dp)
            .clip(CircleShape)
            .background(Color(0x1FE53935))
            .border(1.dp, HeartRed.copy(alpha = 0.35f), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Favorite,
            contentDescription = null,
            modifier = Modifier.size(36.dp),
            tint = HeartRed
          )
        }
        Spacer(modifier = Modifier.height(18.dp))
        Text(
          text = stringResource(R.string.queue_empty_title),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = TextDeepCharcoal,
          letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = stringResource(R.string.queue_empty_subtitle),
          style = MaterialTheme.typography.bodyMedium,
          color = TextPlumMedium,
          textAlign = TextAlign.Center,
          lineHeight = 20.sp,
          modifier = Modifier.padding(horizontal = 24.dp)
        )
      }
    }
  } else {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .testTag("queue_list"),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(bottom = 24.dp)
    ) {
      items(uiState.queueItems, key = { it.id }) { item ->
        val isExpanded = uiState.expandedItemIds.contains(item.id)
        val images = uiState.itemImages[item.id] ?: emptyList()
        DownloadItemCard(
          item = item,
          images = images,
          isExpanded = isExpanded,
          onCardClick = { onToggleItemExpansion(item.id) },
          onDismiss = { onDeleteItem(item.id) },
          onOpenPreview = { onOpenPreview(item) },
          onShowLog = { onShowLog(item) },
          onRetry = { onRetryItem(it.id) }
        )
      }
    }
  }
}

@Composable
fun HistoryTabContent(
  sessions: List<SessionWithImages>,
  onDeleteSession: (Long) -> Unit,
  onClearAllHistory: () -> Unit,
  onImageClick: (SessionImage) -> Unit
) {
  val totalImages = remember(sessions) { sessions.sumOf { it.session.imageCount } }
  val totalBytes = remember(sessions) { sessions.sumOf { it.session.totalBytes } }

  Column(modifier = Modifier.fillMaxSize()) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MattePinkSurface,
          border = BorderStroke(1.dp, MatteBorder)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Favorite,
              contentDescription = null,
              tint = HeartRed,
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "${sessions.size} Sitzungen",
              fontFamily = FontFamily.Monospace,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = TextDeepCharcoal
            )
          }
        }

        if (totalImages > 0) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MattePinkSurface,
            border = BorderStroke(1.dp, MatteBorder)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.PhotoLibrary,
                contentDescription = null,
                tint = StatusSuccess,
                modifier = Modifier.size(15.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "$totalImages Bilder",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextDeepCharcoal
              )
            }
          }
        }

        if (totalBytes > 0) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MattePinkSurface,
            border = BorderStroke(1.dp, MatteBorder)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.SdStorage,
                contentDescription = null,
                tint = BerryPrimary,
                modifier = Modifier.size(15.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = formatFileSize(totalBytes),
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextDeepCharcoal
              )
            }
          }
        }
      }

      if (sessions.isNotEmpty()) {
        IconButton(
          onClick = onClearAllHistory,
          modifier = Modifier
            .size(34.dp)
            .testTag("clear_history_button")
        ) {
          Icon(
            imageVector = Icons.Default.DeleteOutline,
            contentDescription = "Historie leeren",
            tint = StatusError,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }

    if (sessions.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Box(
            modifier = Modifier
              .size(76.dp)
              .clip(CircleShape)
              .background(Color(0x1FE53935))
              .border(1.dp, HeartRed.copy(alpha = 0.35f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Favorite,
              contentDescription = null,
              modifier = Modifier.size(36.dp),
              tint = HeartRed
            )
          }
          Spacer(modifier = Modifier.height(18.dp))
          Text(
            text = "Keine Download-Historie",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextDeepCharcoal,
            letterSpacing = 0.5.sp
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Sobald eine Download-Sitzung in der Queue erfolgreich abgeschlossen ist, werden alle Bildersätze dauerhaft hier in der lokalen Room-Datenbank gespeichert.",
            style = MaterialTheme.typography.bodyMedium,
            color = TextPlumMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
          )
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .testTag("history_list"),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
      ) {
        items(sessions, key = { it.session.id }) { sessionWithImages ->
          SessionCard(
            sessionWithImages = sessionWithImages,
            onDeleteSession = { onDeleteSession(sessionWithImages.session.id) },
            onImageClick = onImageClick
          )
        }
      }
    }
  }
}
