package com.example.data

import java.util.UUID

/**
 * Model representing an image candidate discovered during Phase 1 (crawl)
 * that the user can inspect, preview, and toggle before bulk downloading.
 *
 * [thumbnailUrl] = kleine Vorschau (was auf der Seite als Thumb gefunden wurde)
 * [originalUrl]  = Fullsize / Gallery-Image (nach tryUpgradeThumbnail)
 */
data class PreviewCandidate(
  val id: String = UUID.randomUUID().toString(),
  /** Fullsize-URL, die beim Download verwendet wird */
  val originalUrl: String,
  /** Thumbnail-URL für die Vorschau-Anzeige (klein, schnell) */
  val thumbnailUrl: String = originalUrl,
  val width: Int = 0,
  val height: Int = 0,
  val estimatedSizeKb: Int = 0,
  val isSelected: Boolean = true
)
