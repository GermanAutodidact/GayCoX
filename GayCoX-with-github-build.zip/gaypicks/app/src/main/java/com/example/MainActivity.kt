package com.example

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.BatchViewModel
import com.example.ui.MainScreen
import com.example.ui.PreviewScreen
import com.example.ui.SettingsScreen
import com.example.ui.theme.GayCoXTheme

enum class Screen {
  MAIN,
  SETTINGS,
  PREVIEW
}

class MainActivity : ComponentActivity() {
  private val viewModel: BatchViewModel by viewModels {
    BatchViewModel.Factory(application)
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    handleIncomingIntent(intent)
    setContent {
      GayCoXTheme {
        GayCoXApp(viewModel = viewModel)
      }
    }
  }

  override fun onResume() {
    super.onResume()
    viewModel.checkClipboardAutonomously()
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    handleIncomingIntent(intent)
  }

  private fun handleIncomingIntent(intent: Intent?) {
    if (intent == null) return
    when (intent.action) {
      Intent.ACTION_SEND -> {
        val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
        if (!sharedText.isNullOrBlank()) {
          viewModel.handleSharedUrl(sharedText)
          return
        }
        val streamUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
          @Suppress("DEPRECATION")
          intent.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
        }
        if (streamUri != null) {
          viewModel.importFromFile(streamUri)
        }
      }
      Intent.ACTION_SEND_MULTIPLE -> {
        val textList = intent.getStringArrayListExtra(Intent.EXTRA_TEXT)
        if (!textList.isNullOrEmpty()) {
          viewModel.handleSharedUrl(textList.joinToString("\n"))
        }
        val uriList = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
          @Suppress("DEPRECATION")
          intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
        }
        uriList?.forEach { uri ->
          viewModel.importFromFile(uri)
        }
      }
    }
  }
}

@Composable
fun GayCoXApp(
  viewModel: BatchViewModel,
  modifier: Modifier = Modifier
) {
  var currentScreen by remember { mutableStateOf(Screen.MAIN) }
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val inputText by viewModel.inputText.collectAsStateWithLifecycle()

  when (currentScreen) {
    Screen.MAIN -> {
      MainScreen(
        uiState = uiState,
        inputText = inputText,
        snackbarMessage = viewModel.snackbarMessage,
        onInputTextChanged = viewModel::onInputTextChanged,
        onAddUrlsToQueue = viewModel::addInputToQueue,
        onImportFromClipboard = viewModel::importFromClipboard,
        onImportFromFile = viewModel::importFromFile,
        onImportDetectedClipboard = viewModel::importDetectedClipboardUrls,
        onDismissClipboardBanner = viewModel::dismissClipboardBanner,
        onStartAll = viewModel::startAll,
        onClearCompleted = viewModel::clearCompleted,
        onClearAll = viewModel::clearAll,
        onDeleteItem = viewModel::deleteItem,
        onToggleItemExpansion = viewModel::toggleItemExpansion,
        onDeleteSession = viewModel::deleteSession,
        onClearAllHistory = viewModel::clearAllHistory,
        onNavigateToSettings = { currentScreen = Screen.SETTINGS },
        onOpenPreviewFromItem = { item ->
          val opened = viewModel.openPreviewFromQueueItem(item)
          if (opened) {
            currentScreen = Screen.PREVIEW
          }
        },
        onRetryItem = viewModel::retryItem,
        modifier = modifier.fillMaxSize()
      )
    }
    Screen.SETTINGS -> {
      SettingsScreen(
        settings = uiState.settings,
        onConcurrencyChange = viewModel::updateConcurrency,
        onMinDimensionChange = viewModel::updateMinDimensionPx,
        onMinSizeKbChange = viewModel::updateMinSizeKb,
        onMaxSizeKbChange = viewModel::updateMaxSizeKb,
        onScrollTimeoutChange = viewModel::updateScrollTimeoutSec,
        onMaxDepthChange = viewModel::updateMaxPageDepth,
        onWifiOnlyChange = viewModel::updateWifiOnly,
        onAutoImportClipboardChange = viewModel::updateAutoImportClipboard,
        onNavigateBack = { currentScreen = Screen.MAIN },
        modifier = modifier.fillMaxSize()
      )
    }
    Screen.PREVIEW -> {
      val candidates by viewModel.previewCandidates.collectAsStateWithLifecycle()
      val title by viewModel.previewTitle.collectAsStateWithLifecycle()
      val domain by viewModel.previewDomain.collectAsStateWithLifecycle()
      PreviewScreen(
        title = title,
        domain = domain,
        candidates = candidates,
        onToggleCandidate = viewModel::togglePreviewCandidate,
        onSelectAll = viewModel::selectAllPreviewCandidates,
        onDeselectAll = viewModel::deselectAllPreviewCandidates,
        onConfirmDownload = { selectedList ->
          viewModel.downloadSelectedPreviewCandidates(selectedList)
          currentScreen = Screen.MAIN
        },
        onNavigateBack = { currentScreen = Screen.MAIN },
        modifier = modifier.fillMaxSize()
      )
    }
  }
}
