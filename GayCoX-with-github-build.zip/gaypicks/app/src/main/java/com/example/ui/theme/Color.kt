package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// GayCoX Matte Soft Pastel Pink & Red Heart Palette
val MattePastelPink = Color(0xFFF8CAD6)
val MattePinkSurface = Color(0xFFFFF0F5)
val MatteCardBg = Color(0xFFFFFFFF)
val MatteBorder = Color(0xFFF0B4C5)
val MatteBorderSubtle = Color(0xFFFCE1E9)

// Vibrant Heart Red & Rich Berry Accents
val HeartRed = Color(0xFFE53935)
val HeartRedDeep = Color(0xFFC62828)
val BerryPrimary = Color(0xFFD81B60)
val RubyAccent = Color(0xFFAD1457)
val SoftBerrySurface = Color(0x18D81B60)
val SoftHeartSurface = Color(0x18E53935)

// High-Contrast Crisp Typography Colors for Light Pink Background
val TextDeepCharcoal = Color(0xFF26121E)
val TextPlumMedium = Color(0xFF4C2037)
val TextMutedPlum = Color(0xFF7D4E64)
val TextWhite = Color(0xFFFFFFFF)

// Dynamic Status Colors
val StatusSuccess = Color(0xFF16A34A)
val StatusError = Color(0xFFE11D48)
val StatusWarning = Color(0xFFD97706)
val StatusActive = Color(0xFFE53935)

// Backwards-compatible aliases for existing composables
val CyberDarkBg = MattePastelPink
val CyberSurface = MatteCardBg
val CyberSurfaceElevated = MattePinkSurface
val CyberBorder = MatteBorder
val CyberBorderSubtle = MatteBorderSubtle
val CyberBorderGlow = HeartRed
val NeonCyan = BerryPrimary
val ElectricAqua = HeartRed
val ElectricIndigo = RubyAccent
val ElectricViolet = Color(0xFFC2185B)
val SoftCyanSurface = SoftHeartSurface
val TextSilver = TextPlumMedium
val TextMuted = TextMutedPlum
val TextDark = TextDeepCharcoal
val CarbonBlack = MattePastelPink
val BarkwoodDark = MattePastelPink
val CharcoalSurface = MatteCardBg
val CharcoalElevated = MattePinkSurface
val AshBorder = MatteBorder
val AshBorderSubtle = MatteBorderSubtle
val MonoPureWhite = TextWhite
val MonoBoneWhite = TextPlumMedium
val MonoSilver = TextMutedPlum
val MonoMuted = TextMutedPlum
val MonoDeepAsh = MatteBorder
