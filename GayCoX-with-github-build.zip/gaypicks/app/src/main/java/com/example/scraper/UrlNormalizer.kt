package com.example.scraper

import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URI
import java.util.Locale
import java.util.regex.Pattern

object UrlNormalizer {
  private val URL_REGEX = Pattern.compile(
    "\\b(https?://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|])",
    Pattern.CASE_INSENSITIVE
  )

  private val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "gif")

  private const val DESKTOP_UA =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

  private val THUMB_PATH_DIMENSIONS = Regex("/t\\d{2,4}x\\d{2,4}/", RegexOption.IGNORE_CASE)
  private val THUMB_PATH_W_OR_H = Regex("/[wh]\\d{2,4}/", RegexOption.IGNORE_CASE)
  private val THUMB_PATTERN_1 = Regex("[-_]\\d{2,4}x\\d{2,4}(?=\\.[a-zA-Z0-9]+$)")
  private val THUMB_PATTERN_2 = Regex("/(thumbs?|thumbnails?|preview|small|mini|t|sm)/", RegexOption.IGNORE_CASE)
  private val THUMB_PATTERN_3 = Regex("([?&](?:w|width|size|resize|scale|h|height|maxwidth)=\\d+[^&]*)", RegexOption.IGNORE_CASE)
  private val THUMB_PATTERN_4 = Regex("[-_](thumb|preview|small|tiny|mini|th|t|m|s)(?=\\.[a-zA-Z0-9]+$)", RegexOption.IGNORE_CASE)
  private val WIKI_THUMB_PATTERN = Regex("/thumb/(.+)/\\d+px-[^/]+$", RegexOption.IGNORE_CASE)
  private val BLOGSPOT_SIZE_PATTERN = Regex("/s\\d+(-c)?/", RegexOption.IGNORE_CASE)
  private val IMGUR_SUFFIX_PATTERN = Regex("([a-zA-Z0-9]{5,8})[smlht](?=\\.(?:jpg|jpeg|png|webp)$)", RegexOption.IGNORE_CASE)

  /**
   * Checks if candidate belongs to the same domain as baseUrl and is a valid web subpage (not anchor, not file).
   */
  fun isSameDomainSubpage(baseUrl: String, candidateUrl: String): Boolean {
    val baseDomain = getDomain(baseUrl)
    val candidateDomain = getDomain(candidateUrl)
    if (baseDomain.isBlank() || candidateDomain.isBlank()) return false
    if (!baseDomain.equals(candidateDomain, ignoreCase = true)) return false
    val lower = candidateUrl.lowercase(Locale.ROOT)
    if (lower.contains("#") && lower.substringBefore('#') == baseUrl.substringBefore('#')) return false
    if (lower.contains("logout") || lower.contains("login") || lower.contains("signin") ||
      lower.contains("signup") || lower.contains("cart") || lower.contains("checkout")
    ) return false
    // Exclude direct media files as subpages
    if (isSupportedImage(candidateUrl) || lower.endsWith(".pdf") || lower.endsWith(".zip")) return false
    return true
  }

  /**
   * Extracts URLs from freeform multiline text.
   */
  fun extractUrls(text: String): List<String> {
    val results = mutableListOf<String>()
    val lines = text.lines()
    for (line in lines) {
      val trimmed = line.trim()
      if (trimmed.isEmpty()) continue
      val matcher = URL_REGEX.matcher(trimmed)
      while (matcher.find()) {
        val found = matcher.group(1)?.trim() ?: continue
        if (isValidHttpUrl(found)) {
          results.add(normalizeWebUrl(found))
        }
      }
    }
    return results.distinct()
  }

  fun isValidHttpUrl(url: String): Boolean {
    return url.startsWith("http://", ignoreCase = true) || url.startsWith("https://", ignoreCase = true)
  }

  fun normalizeWebUrl(url: String): String {
    return url.trim()
  }

  fun getDomain(url: String): String {
    return try {
      val uri = URI(url)
      val host = uri.host ?: ""
      if (host.startsWith("www.")) host.substring(4) else host
    } catch (_: Exception) {
      ""
    }
  }

  /**
   * Resolves relative URLs to absolute based on the page's base URL.
   */
  fun resolveUrl(baseUrl: String, candidate: String): String? {
    val trimmed = candidate.trim()
    if (trimmed.isEmpty() || trimmed.startsWith("data:") || trimmed.startsWith("javascript:") || trimmed.startsWith("blob:")) {
      return null
    }
    // Direct HTTP/HTTPS URL
    if (isValidHttpUrl(trimmed)) {
      // Fix potential accidental double-domain path (e.g. https://domain.com/path/i.domain.com/...)
      val doubleDomain = Regex("^https?://[^/]+/[^?#]*/((?:i\\.|cdn\\.|media\\.|img\\.|images\\.|assets\\.)[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}/.*)", RegexOption.IGNORE_CASE).find(trimmed)
      if (doubleDomain != null) {
        val inner = doubleDomain.groupValues[1]
        val clean = (if (inner.startsWith("http://", ignoreCase = true) || inner.startsWith("https://", ignoreCase = true)) "" else "https://") + inner
        return clean
      }
      return trimmed
    }
    // Protocol-relative URLs (e.g. //i.domain.com/scene/...)
    if (trimmed.startsWith("//")) {
      val scheme = if (baseUrl.startsWith("http://", ignoreCase = true)) "http:" else "https:"
      return scheme + trimmed
    }
    // Schemeless domain URLs (e.g. i.domain.com/scene/...)
    if (trimmed.matches(Regex("^[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}/.*"))) {
      val scheme = if (baseUrl.startsWith("http://", ignoreCase = true)) "http://" else "https://"
      return scheme + trimmed
    }
    return try {
      val baseUri = URI(baseUrl)
      val resolved = baseUri.resolve(trimmed).toString()
      if (isValidHttpUrl(resolved)) resolved else null
    } catch (_: Exception) {
      if (isValidHttpUrl(trimmed)) trimmed else null
    }
  }

  /**
   * Identifies website chrome, icons, logos, tracking pixels and badges that are NOT content images.
   */
  fun isUiAssetOrJunk(url: String): Boolean {
    val lower = url.lowercase(Locale.ROOT)
    val path = lower.substringBefore('?').substringBefore('#')
    val fileName = path.substringAfterLast('/', "")
    if (fileName.contains("favicon") ||
      fileName.contains("apple-icon") ||
      fileName.contains("apple-touch-icon") ||
      fileName.contains("android-icon") ||
      fileName.contains("android-chrome") ||
      fileName.contains("header-logo") ||
      fileName.contains("footer-logo") ||
      fileName.contains("footer-bg") ||
      fileName.contains("88x31") ||
      fileName.contains("rta_") ||
      fileName.contains("rta-") ||
      fileName.contains("rta.") ||
      fileName.contains("spacer.gif") ||
      fileName.contains("blank.gif") ||
      fileName.contains("pixel.gif") ||
      fileName.contains("spinner") ||
      fileName.contains("loader")
    ) return true
    if (path.contains("/icons/") || path.contains("/img/icons/") || path.contains("/assets/icons/")) {
      if (fileName.contains("icon") || fileName.contains("logo") || fileName.contains("favicon")) {
        return true
      }
    }
    return false
  }

  /**
   * Extracts modal or scene ID from URL hashes or paths (e.g. #/modal/scene/238087 or /content/.../238087_...)
   */
  fun extractModalSceneId(url: String): String? {
    val hash = url.substringAfter('#', "")
    if (hash.isNotBlank()) {
      val match = Regex("(?:modal/(?:scene|video)/|scene[/_-]?)(\\d+)", RegexOption.IGNORE_CASE).find(hash)
      if (match != null) {
        return match.groupValues[1]
      }
    }
    val pathMatch = Regex("(?:/scene/|/)(\\d{4,9})(?:_[^/]*|$)", RegexOption.IGNORE_CASE).find(url.substringBefore('#'))
    return pathMatch?.groupValues?.get(1)
  }

  /**
   * Parses srcset strings and returns the URL with the largest descriptor (e.g. 2000w or 3x).
   */
  fun getLargestFromSrcset(srcsetString: String, baseUrl: String): String? {
    if (srcsetString.isBlank()) return null
    val entries = srcsetString.split(",")
    var bestUrl: String? = null
    var bestScore = -1.0
    for (entry in entries) {
      val parts = entry.trim().split("\\s+".toRegex())
      if (parts.isEmpty()) continue
      val url = parts[0]
      val descriptor = if (parts.size > 1) parts[1].lowercase(Locale.ROOT) else "1x"
      val score = when {
        descriptor.endsWith("w") -> descriptor.removeSuffix("w").toDoubleOrNull() ?: 1.0
        descriptor.endsWith("x") -> (descriptor.removeSuffix("x").toDoubleOrNull() ?: 1.0) * 1000.0
        else -> 1.0
      }
      if (score > bestScore) {
        bestScore = score
        bestUrl = url
      }
    }
    return bestUrl?.let { resolveUrl(baseUrl, it) }
  }

  /**
   * Checks if an image candidate has a supported extension or mime clue.
   */
  fun isSupportedImage(url: String): Boolean {
    if (isUiAssetOrJunk(url)) return false
    val cleanUrl = url.substringBefore('?').substringBefore('#').lowercase(Locale.ROOT)
    val ext = cleanUrl.substringAfterLast('.', "")
    if (IMAGE_EXTENSIONS.contains(ext)) return true
    // Check query params if dynamic image handler
    val lower = url.lowercase(Locale.ROOT)
    return lower.contains("format=jpg") || lower.contains("format=jpeg") ||
      lower.contains("format=png") || lower.contains("format=webp") ||
      lower.contains("image/") || lower.contains("/photo/") || lower.contains("/images/")
  }

  /**
   * Attempts to rewrite common thumbnail patterns to original full-resolution URLs.
   * Tests potential upgrades with User-Agent and Referer against the server.
   */
  suspend fun tryUpgradeThumbnail(url: String, client: OkHttpClient, referer: String? = null): String {
    val candidatesToTry = mutableListOf<String>()
    // 1. Tube / Scene dimension paths: /t300x400/ -> /t1600x1600/, /t1920x1080/, or stripping /
    if (THUMB_PATH_DIMENSIONS.containsMatchIn(url)) {
      candidatesToTry.add(THUMB_PATH_DIMENSIONS.replace(url, "/t1600x1600/"))
      candidatesToTry.add(THUMB_PATH_DIMENSIONS.replace(url, "/t1920x1080/"))
      candidatesToTry.add(THUMB_PATH_DIMENSIONS.replace(url, "/"))
    }
    // 2. Tube width/height paths: /w300/ or /h205/ -> /t1600x1600/ or /
    if (THUMB_PATH_W_OR_H.containsMatchIn(url)) {
      candidatesToTry.add(THUMB_PATH_W_OR_H.replace(url, "/t1600x1600/"))
      candidatesToTry.add(THUMB_PATH_W_OR_H.replace(url, "/"))
    }
    // 3. Filename dimension suffixes: image_800x600.jpg -> image.jpg
    if (THUMB_PATTERN_1.containsMatchIn(url)) {
      candidatesToTry.add(THUMB_PATTERN_1.replace(url, ""))
    }
    // 4. Common thumb directory folders: /thumbs/ -> /
    if (THUMB_PATTERN_2.containsMatchIn(url)) {
      candidatesToTry.add(THUMB_PATTERN_2.replace(url, "/"))
      candidatesToTry.add(THUMB_PATTERN_2.replace(url, "/original/"))
      candidatesToTry.add(THUMB_PATTERN_2.replace(url, "/full/"))
    }
    // 5. Query parameter resizing: ?w=300
    if (THUMB_PATTERN_3.containsMatchIn(url)) {
      candidatesToTry.add(THUMB_PATTERN_3.replace(url, ""))
    }
    // 6. Name suffix: image-thumb.jpg -> image.jpg
    if (THUMB_PATTERN_4.containsMatchIn(url)) {
      candidatesToTry.add(THUMB_PATTERN_4.replace(url, ""))
    }
    // 7. Wikipedia / Wikimedia: /thumb/.../px-... -> full image
    if (url.contains("/thumb/") && WIKI_THUMB_PATTERN.containsMatchIn(url)) {
      candidatesToTry.add(WIKI_THUMB_PATTERN.replace(url) { matchResult ->
        "/${matchResult.groupValues[1]}"
      })
    }
    // 8. Blogspot: /s320/ or /s160-c/ -> /s0/ (original maximum resolution)
    if (BLOGSPOT_SIZE_PATTERN.containsMatchIn(url)) {
      candidatesToTry.add(BLOGSPOT_SIZE_PATTERN.replace(url, "/s0/"))
    }
    // 9. Reddit preview: preview.redd.it -> i.redd.it
    if (url.contains("preview.redd.it")) {
      candidatesToTry.add(url.replace("preview.redd.it", "i.redd.it").substringBefore('?'))
    }
    // 10. Imgur thumbnail suffix letter
    if (url.contains("imgur.com") && IMGUR_SUFFIX_PATTERN.containsMatchIn(url)) {
      candidatesToTry.add(IMGUR_SUFFIX_PATTERN.replace(url) { it.groupValues[1] })
    }
    val distinctCandidates = candidatesToTry.distinct().filter { it != url }
    if (distinctCandidates.isEmpty()) return url
    for (candidate in distinctCandidates) {
      try {
        val reqBuilder = Request.Builder()
          .url(candidate)
          .header("User-Agent", DESKTOP_UA)
          .header("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8")
          .head()
        if (!referer.isNullOrBlank()) {
          reqBuilder.header("Referer", referer)
        }
        val response = client.newCall(reqBuilder.build()).execute()
        val isSuccess = response.isSuccessful
        val contentType = response.header("Content-Type") ?: ""
        response.close()
        if (isSuccess && (contentType.startsWith("image/") || contentType.isBlank())) {
          return candidate
        }
        // If HEAD failed with 403/404/405, test with a small GET Range request
        if (!isSuccess && (response.code == 404 || response.code == 405 || response.code == 403)) {
          val getReq = Request.Builder()
            .url(candidate)
            .header("User-Agent", DESKTOP_UA)
            .header("Range", "bytes=0-1024")
          if (!referer.isNullOrBlank()) {
            getReq.header("Referer", referer)
          }
          val getResp = client.newCall(getReq.build()).execute()
          val getSuccess = getResp.isSuccessful
          val getContentType = getResp.header("Content-Type") ?: ""
          getResp.close()
          if (getSuccess && (getContentType.startsWith("image/") || getContentType.isBlank())) {
            return candidate
          }
        }
      } catch (_: Exception) {}
    }
    // Fallback: If candidate matches known deterministic high-res tube pattern, prefer it
    val deterministicUpgrade = distinctCandidates.firstOrNull { it.contains("/t1600x1600/") }
    return deterministicUpgrade ?: url
  }
}
