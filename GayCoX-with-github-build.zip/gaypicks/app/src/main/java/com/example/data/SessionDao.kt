package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface SessionDao {
  @Transaction
  @Query("SELECT * FROM download_sessions ORDER BY completedAt DESC")
  fun getAllSessionsWithImages(): Flow<List<SessionWithImages>>

  @Transaction
  @Query("SELECT * FROM download_sessions WHERE id = :sessionId")
  suspend fun getSessionWithImages(sessionId: Long): SessionWithImages?

  @Query("SELECT * FROM download_sessions ORDER BY completedAt DESC")
  fun getAllSessions(): Flow<List<DownloadSession>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSession(session: DownloadSession): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSessionImages(images: List<SessionImage>)

  @Query("DELETE FROM download_sessions WHERE id = :sessionId")
  suspend fun deleteSessionById(sessionId: Long)

  @Query("DELETE FROM download_sessions")
  suspend fun clearAllSessions()
}
