package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class Converters {
  @TypeConverter
  fun fromQueueStatus(status: QueueStatus): String = status.name

  @TypeConverter
  fun toQueueStatus(value: String): QueueStatus =
    runCatching { QueueStatus.valueOf(value) }.getOrDefault(QueueStatus.WAITING)
}

@Database(
  entities = [
    QueueItem::class,
    DownloadedImage::class,
    DownloadSession::class,
    SessionImage::class
  ],
  version = 3,
  exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
  abstract fun queueDao(): QueueDao
  abstract fun sessionDao(): SessionDao

  companion object {
    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getInstance(context: Context): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance =
          Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "gaycox.db"
          )
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
