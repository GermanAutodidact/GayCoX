package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.DownloadSession
import com.example.data.SessionImage
import com.example.scraper.UrlNormalizer
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("GayCoX", appName)
  }

  @Test
  fun `test url extraction and domain extraction`() {
    val input = "Check out https://unsplash.com/photos/123 and http://example.com/gallery"
    val extracted = UrlNormalizer.extractUrls(input)
    assertEquals(2, extracted.size)
    assertEquals("https://unsplash.com/photos/123", extracted[0])
    assertEquals("unsplash.com", UrlNormalizer.getDomain(extracted[0]))
  }

  @Test
  fun `test supported image checking`() {
    assertTrue(UrlNormalizer.isSupportedImage("https://example.com/image.jpg"))
    assertTrue(UrlNormalizer.isSupportedImage("https://example.com/photo.PNG?width=800"))
    assertTrue(UrlNormalizer.isSupportedImage("https://example.com/graphic.webp"))
  }

  @Test
  fun `test download sessions history room persistence`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    val sessionDao = db.sessionDao()

    val session = DownloadSession(
      title = "Nature Wallpapers",
      sourceUrl = "https://example.com/nature",
      domain = "example.com",
      imageCount = 2,
      totalBytes = 1024L * 500,
      folderName = "Nature Wallpapers"
    )
    val sessionId = sessionDao.insertSession(session)
    assertTrue(sessionId > 0)

    val images = listOf(
      SessionImage(
        sessionId = sessionId,
        originalUrl = "https://example.com/img1.jpg",
        localUri = "content://media/external/images/media/101",
        fileName = "img1.jpg",
        fileSize = 250_000L,
        width = 1920,
        height = 1080
      ),
      SessionImage(
        sessionId = sessionId,
        originalUrl = "https://example.com/img2.jpg",
        localUri = "content://media/external/images/media/102",
        fileName = "img2.jpg",
        fileSize = 250_000L,
        width = 1920,
        height = 1080
      )
    )
    sessionDao.insertSessionImages(images)

    val sessionsWithImages = sessionDao.getAllSessionsWithImages().first()
    assertEquals(1, sessionsWithImages.size)
    assertEquals("Nature Wallpapers", sessionsWithImages[0].session.title)
    assertEquals(2, sessionsWithImages[0].images.size)
    assertEquals("img1.jpg", sessionsWithImages[0].images[0].fileName)

    sessionDao.deleteSessionById(sessionId)
    val afterDelete = sessionDao.getAllSessionsWithImages().first()
    assertEquals(0, afterDelete.size)

    db.close()
  }
}
