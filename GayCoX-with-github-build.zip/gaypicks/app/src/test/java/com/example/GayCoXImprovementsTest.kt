package com.example

import com.example.data.PreviewCandidate
import com.example.scraper.UrlNormalizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class GayCoXImprovementsTest {

  @Test
  fun testPreviewCandidateCreationAndDefaults() {
    val candidate = PreviewCandidate(
      originalUrl = "https://example.com/images/full_photo.jpg",
      thumbnailUrl = "https://example.com/thumbs/photo.jpg",
      width = 1920,
      height = 1080,
      estimatedSizeKb = 250
    )
    assertNotNull(candidate.id)
    assertEquals("https://example.com/images/full_photo.jpg", candidate.originalUrl)
    assertEquals("https://example.com/thumbs/photo.jpg", candidate.thumbnailUrl)
    assertEquals(1920, candidate.width)
    assertEquals(1080, candidate.height)
    assertEquals(250, candidate.estimatedSizeKb)
    assertTrue("Candidates should be selected by default", candidate.isSelected)
  }

  @Test
  fun testPreviewCandidateToggleSelection() {
    val candidate = PreviewCandidate(
      originalUrl = "https://example.com/img.jpg"
    )
    assertTrue(candidate.isSelected)
    val toggledOff = candidate.copy(isSelected = !candidate.isSelected)
    assertFalse(toggledOff.isSelected)
    val toggledOn = toggledOff.copy(isSelected = !toggledOff.isSelected)
    assertTrue(toggledOn.isSelected)
  }

  @Test
  fun testBulkSelectionLogic() {
    val candidates = listOf(
      PreviewCandidate(originalUrl = "https://example.com/1.jpg", isSelected = true),
      PreviewCandidate(originalUrl = "https://example.com/2.jpg", isSelected = false),
      PreviewCandidate(originalUrl = "https://example.com/3.jpg", isSelected = true)
    )
    assertEquals(2, candidates.count { it.isSelected })

    val allDeselected = candidates.map { it.copy(isSelected = false) }
    assertEquals(0, allDeselected.count { it.isSelected })

    val allSelected = allDeselected.map { it.copy(isSelected = true) }
    assertEquals(3, allSelected.count { it.isSelected })
  }

  @Test
  fun testUrlNormalizerWithComplexCandidates() {
    val rawUrls = listOf(
      "https://example.com/photo.png?width=1200",
      "https://example.com/thumb/test.jpg",
      "https://example.com/vector.svg",
      "https://example.com/photo.webp"
    )
    val supported = rawUrls.filter { UrlNormalizer.isSupportedImage(it) }
    assertEquals(3, supported.size)
    assertFalse(supported.contains("https://example.com/vector.svg"))
  }

  @Test
  fun testProtocolRelativeAndSchemelessUrlResolution() {
    val baseUrl = "https://example.com/gallery/page1"

    val protoRelative = "//i.example.com/scene/123/img.jpg"
    val resolvedProto = UrlNormalizer.resolveUrl(baseUrl, protoRelative)
    assertEquals("https://i.example.com/scene/123/img.jpg", resolvedProto)

    val schemeless = "i.example.com/scene/123/img.jpg"
    val resolvedSchemeless = UrlNormalizer.resolveUrl(baseUrl, schemeless)
    assertEquals("https://i.example.com/scene/123/img.jpg", resolvedSchemeless)

    val standardRelative = "/images/photo.jpg"
    val resolvedStandard = UrlNormalizer.resolveUrl(baseUrl, standardRelative)
    assertEquals("https://example.com/images/photo.jpg", resolvedStandard)
  }

  @Test
  fun testModalSceneIdExtraction() {
    val modalUrl1 = "https://dbnaked.com/shemale/channels/joannajet.com?media=pictures#/modal/scene/238087"
    val id1 = UrlNormalizer.extractModalSceneId(modalUrl1)
    assertEquals("238087", id1)

    val modalUrl2 = "https://dbnaked.com/pictures/content/shemale/sites/joannajet/238087_go-for-gold"
    val id2 = UrlNormalizer.extractModalSceneId(modalUrl2)
    assertEquals("238087", id2)

    val genericUrl = "https://example.com/gallery"
    val idGeneric = UrlNormalizer.extractModalSceneId(genericUrl)
    assertEquals(null, idGeneric)
  }

  @Test
  fun testUiAssetOrJunkFiltering() {
    val junkAssets = listOf(
      "https://assets.example.com/build/img/icons/favicon-32x32.png?v=ef977080.png",
      "https://assets.example.com/build/img/header-logo-2.b590b860.png",
      "https://assets.example.com/build/img/icons/android-icon-192x192.png",
      "https://assets.example.com/build/img/icons/apple-icon-180x180.png",
      "https://assets.example.com/build/img/footer-logo.681219ef.png",
      "https://assets.example.com/build/images/footer-bg.710a326e..jpg",
      "https://assets.example.com/build/img/88x31_RTA-5042.gif"
    )
    for (junk in junkAssets) {
      assertTrue("Should be identified as UI asset or junk: $junk", UrlNormalizer.isUiAssetOrJunk(junk))
      assertFalse("Should NOT be supported content image: $junk", UrlNormalizer.isSupportedImage(junk))
    }

    val realContentImages = listOf(
      "https://i.example.com/scene/238087/t1600x1600/1.jpg",
      "https://i.example.com/scene/196049/t300x400/8.jpg",
      "https://cdn.photos.com/albums/vacation/p1.webp"
    )
    for (real in realContentImages) {
      assertFalse("Should NOT be junk: $real", UrlNormalizer.isUiAssetOrJunk(real))
      assertTrue("Should be supported image: $real", UrlNormalizer.isSupportedImage(real))
    }
  }

  @Test
  fun testDoubleDomainUrlCleanup() {
    val malformed = "https://dbnaked.com/shemale/channels/i.dbnaked.com/scene/196049/t300x400/8.jpg"
    val cleaned = UrlNormalizer.resolveUrl("https://dbnaked.com", malformed)
    assertEquals("https://i.dbnaked.com/scene/196049/t300x400/8.jpg", cleaned)
  }

  @Test
  fun testTubeThumbnailUpgradeCandidate() {
    val thumbUrl = "https://i.dbnaked.com/scene/238087/t300x400/7.jpg"
    val upgraded = kotlinx.coroutines.runBlocking {
      UrlNormalizer.tryUpgradeThumbnail(thumbUrl, okhttp3.OkHttpClient())
    }
    assertEquals("https://i.dbnaked.com/scene/238087/t1600x1600/7.jpg", upgraded)
  }
}
