package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.AppSettings
import com.example.data.DownloadSession
import com.example.data.QueueItem
import com.example.data.QueueStatus
import com.example.data.SessionImage
import com.example.scraper.UrlNormalizer
import com.example.ui.formatFileSize
import com.example.worker.MediaSaver
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class GayCoXComprehensiveTestSuite {

  private val context: Context
    get() = ApplicationProvider.getApplicationContext()

  @Test
  fun test01_urlExtractionFromMessyText() {
    val messyInput = """
      Check this out: https://example.com/gallery/photos
      Also here is an insecure link: http://sub.domain.org/items?cat=1&page=2#top
      Random text without link: example.org/nomatch
      Another line: https://images.site.com/view/456.html
    """.trimIndent()

    val urls = UrlNormalizer.extractUrls(messyInput)
    assertEquals(3, urls.size)
    assertTrue(urls.contains("https://example.com/gallery/photos"))
    assertTrue(urls.contains("http://sub.domain.org/items?cat=1&page=2#top"))
    assertTrue(urls.contains("https://images.site.com/view/456.html"))
  }

  @Test
  fun test02_domainExtraction() {
    assertEquals("example.com", UrlNormalizer.getDomain("https://www.example.com/page"))
    assertEquals("sub.domain.org", UrlNormalizer.getDomain("http://sub.domain.org:8080/path"))
    assertEquals("testsite.de", UrlNormalizer.getDomain("https://testsite.de/gallery/view?id=12"))
    assertEquals("", UrlNormalizer.getDomain("not a valid url"))
  }

  @Test
  fun test03_thumbnailPatternRewriting() {
    val wpThumb = "https://example.com/uploads/photo_800x600.jpg"
    val wpUpgraded = wpThumb.replace(Regex("[-_]\\d{2,4}x\\d{2,4}(?=\\.[a-zA-Z0-9]+$)"), "")
    assertEquals("https://example.com/uploads/photo.jpg", wpUpgraded)

    val dirThumb = "https://example.com/thumbs/nature_pic.jpg"
    val dirUpgraded = dirThumb.replace(Regex("/(thumbs?|thumbnails?|preview|small|mini)/", RegexOption.IGNORE_CASE), "/")
    assertEquals("https://example.com/nature_pic.jpg", dirUpgraded)

    val suffixThumb = "https://example.com/gallery/car_thumb.jpg"
    val suffixUpgraded = suffixThumb.replace(Regex("[-_](thumb|preview|small|tiny|mini|th|t|m|s)(?=\\.[a-zA-Z0-9]+$)", RegexOption.IGNORE_CASE), "")
    assertEquals("https://example.com/gallery/car.jpg", suffixUpgraded)
  }

  @Test
  fun test04_specialPlatformThumbnailUpgrades() {
    val wikiThumb = "https://upload.wikimedia.org/wikipedia/commons/thumb/a/b/Beautiful_View.jpg/320px-Beautiful_View.jpg"
    val wikiRegex = Regex("/thumb/(.+)/\\d+px-[^/]+$", RegexOption.IGNORE_CASE)
    val wikiUpgraded = wikiRegex.replace(wikiThumb) { "/${it.groupValues[1]}" }
    assertEquals("https://upload.wikimedia.org/wikipedia/commons/a/b/Beautiful_View.jpg", wikiUpgraded)

    val blogspotThumb = "https://1.bp.blogspot.com/-xyz/s320/wallpaper.jpg"
    val blogspotRegex = Regex("/s\\d+(-c)?/", RegexOption.IGNORE_CASE)
    val blogspotUpgraded = blogspotRegex.replace(blogspotThumb, "/s0/")
    assertEquals("https://1.bp.blogspot.com/-xyz/s0/wallpaper.jpg", blogspotUpgraded)

    val redditPreview = "https://preview.redd.it/xyz123.jpg?width=640&crop=smart"
    val redditUpgraded = redditPreview.replace("preview.redd.it", "i.redd.it").substringBefore('?')
    assertEquals("https://i.redd.it/xyz123.jpg", redditUpgraded)
  }

  @Test
  fun test05_sameDomainSubpageDetection() {
    val base = "https://example.com/category/nature"

    assertTrue(UrlNormalizer.isSameDomainSubpage(base, "https://example.com/category/nature/page/2"))
    assertTrue(UrlNormalizer.isSameDomainSubpage(base, "https://example.com/gallery/123"))

    assertFalse(UrlNormalizer.isSameDomainSubpage(base, "https://otherdomain.com/category/nature"))
    assertFalse(UrlNormalizer.isSameDomainSubpage(base, "https://facebook.com/share"))

    assertFalse(UrlNormalizer.isSameDomainSubpage(base, "https://example.com/category/nature#comments"))
    assertFalse(UrlNormalizer.isSameDomainSubpage(base, "https://example.com/auth/logout"))
    assertFalse(UrlNormalizer.isSameDomainSubpage(base, "https://example.com/download.pdf"))
    assertFalse(UrlNormalizer.isSameDomainSubpage(base, "https://example.com/images/full.jpg"))
  }

  @Test
  fun test06_srcsetHighestResolutionSelection() {
    val base = "https://example.com"
    val srcset = "small.jpg 300w, medium.jpg 800w, large.jpg 2048w, ultra.jpg 4096w"
    val best = UrlNormalizer.getLargestFromSrcset(srcset, base)
    assertEquals("https://example.com/ultra.jpg", best)

    val pixelDensitySrcset = "pic-1x.jpg 1x, pic-2x.jpg 2x, pic-3x.jpg 3x"
    val bestDensity = UrlNormalizer.getLargestFromSrcset(pixelDensitySrcset, base)
    assertEquals("https://example.com/pic-3x.jpg", bestDensity)
  }

  @Test
  fun test07_magicBytesAndMimeDetection() {
    val jpegBytes = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte())
    val pngBytes = byteArrayOf(0x89.toByte(), 0x50.toByte(), 0x4E.toByte(), 0x47.toByte(), 0x0D.toByte())
    val gifBytes = byteArrayOf(0x47.toByte(), 0x49.toByte(), 0x46.toByte(), 0x38.toByte(), 0x39.toByte())

    assertEquals(Pair("image/jpeg", "jpg"), MediaSaver.determineMimeAndExt(jpegBytes, "file"))
    assertEquals(Pair("image/png", "png"), MediaSaver.determineMimeAndExt(pngBytes, "file"))
    assertEquals(Pair("image/gif", "gif"), MediaSaver.determineMimeAndExt(gifBytes, "file"))
  }

  @Test
  fun test08_minSizeFilterEnforcement() {
    val smallBytes = ByteArray(50 * 1024)
    val validatedSmall = MediaSaver.validateImage(smallBytes, minSizeKb = 100, minDimensionPx = 400)
    assertNull(validatedSmall)

    val bitmap = Bitmap.createBitmap(600, 600, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(Color.BLUE)
    val outputStream = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
    val validBytes = outputStream.toByteArray()

    val validatedValid = MediaSaver.validateImage(validBytes, minSizeKb = 0, minDimensionPx = 400)
    assertNotNull(validatedValid)
    assertEquals(600, validatedValid?.first)
    assertEquals(600, validatedValid?.second)

    val tinyBitmap = Bitmap.createBitmap(200, 200, Bitmap.Config.ARGB_8888)
    val tinyStream = ByteArrayOutputStream()
    tinyBitmap.compress(Bitmap.CompressFormat.JPEG, 100, tinyStream)
    val tinyBytes = tinyStream.toByteArray()
    val validatedTiny = MediaSaver.validateImage(tinyBytes, minSizeKb = 0, minDimensionPx = 400)
    assertNull(validatedTiny)
  }

  @Test
  fun test09_mandatoryJpgConversionWithAlphaHandling() {
    val alphaBitmap = Bitmap.createBitmap(500, 500, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(alphaBitmap)
    canvas.drawColor(Color.TRANSPARENT)
    val paint = android.graphics.Paint().apply { color = Color.RED }
    canvas.drawCircle(250f, 250f, 150f, paint)
    val pngStream = ByteArrayOutputStream()
    alphaBitmap.compress(Bitmap.CompressFormat.PNG, 100, pngStream)
    val rawPngBytes = pngStream.toByteArray()

    val processed = MediaSaver.processAndConvertToJpg(rawPngBytes, maxSizeKb = 300)
    assertNotNull(processed)
    assertEquals("image/jpeg", processed?.mimeType)
    assertEquals("jpg", processed?.ext)
    assertTrue(processed!!.bytes.isNotEmpty())

    assertEquals(0xFF.toByte(), processed.bytes[0])
    assertEquals(0xD8.toByte(), processed.bytes[1])
    assertEquals(0xFF.toByte(), processed.bytes[2])
  }

  @Test
  fun test10_automaticCompressionUnder300Kb() {
    val largeBitmap = Bitmap.createBitmap(1200, 1200, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(largeBitmap)
    for (i in 0 until 1200 step 20) {
      val paint = android.graphics.Paint().apply {
        color = Color.rgb((i % 256), ((i * 3) % 256), ((i * 7) % 256))
      }
      canvas.drawRect(i.toFloat(), 0f, (i + 20).toFloat(), 1200f, paint)
    }
    val stream = ByteArrayOutputStream()
    largeBitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream)
    val uncompressedBytes = stream.toByteArray()

    val processed = MediaSaver.processAndConvertToJpg(uncompressedBytes, maxSizeKb = 300)
    assertNotNull(processed)
    assertTrue("Result must be <= 300 KB", processed!!.bytes.size <= 300 * 1024)
    assertEquals("jpg", processed.ext)
    assertEquals("image/jpeg", processed.mimeType)
  }

  @Test
  fun test11_queueItemDatabaseLifecycle() = runBlocking {
    val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    val queueDao = db.queueDao()

    val item = QueueItem(
      url = "https://example.com/gallery",
      domain = "example.com",
      status = QueueStatus.WAITING
    )
    val itemId = queueDao.insertQueueItem(item)
    assertTrue(itemId > 0)

    val waiting = queueDao.getWaitingQueueItems()
    assertEquals(1, waiting.size)
    assertEquals(QueueStatus.WAITING, waiting[0].status)

    queueDao.updateStatus(itemId, QueueStatus.SCANNING, null)
    var updated = queueDao.getQueueItemById(itemId)
    assertEquals(QueueStatus.SCANNING, updated?.status)

    queueDao.updateProgress(itemId, progress = 5, total = 84)
    updated = queueDao.getQueueItemById(itemId)
    assertEquals(5, updated?.progress)
    assertEquals(84, updated?.total)

    queueDao.updateStatus(itemId, QueueStatus.DOWNLOADING, null)
    updated = queueDao.getQueueItemById(itemId)
    assertEquals(QueueStatus.DOWNLOADING, updated?.status)

    queueDao.updateStatus(itemId, QueueStatus.COMPLETED, null)
    updated = queueDao.getQueueItemById(itemId)
    assertEquals(QueueStatus.COMPLETED, updated?.status)

    db.close()
  }

  @Test
  fun test12_downloadSessionAndImagesPersistence() = runBlocking {
    val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    val sessionDao = db.sessionDao()

    val session = DownloadSession(
      title = "Architecture Photos",
      sourceUrl = "https://archdaily.com/posts",
      domain = "archdaily.com",
      imageCount = 2,
      totalBytes = 650_000L,
      folderName = "Architecture Photos"
    )
    val sessionId = sessionDao.insertSession(session)
    assertTrue(sessionId > 0)

    val images = listOf(
      SessionImage(
        sessionId = sessionId,
        originalUrl = "https://archdaily.com/img1.webp",
        localUri = "content://media/external/images/media/201",
        fileName = "img_1_hash.jpg",
        fileSize = 220_000L,
        width = 1600,
        height = 1200
      ),
      SessionImage(
        sessionId = sessionId,
        originalUrl = "https://archdaily.com/img2.png",
        localUri = "content://media/external/images/media/202",
        fileName = "img_2_hash.jpg",
        fileSize = 280_000L,
        width = 1800,
        height = 1200
      )
    )
    sessionDao.insertSessionImages(images)

    val storedSessions = sessionDao.getAllSessionsWithImages().first()
    assertEquals(1, storedSessions.size)
    assertEquals(2, storedSessions[0].images.size)
    assertTrue(storedSessions[0].images.all { it.fileName.endsWith(".jpg") })

    sessionDao.deleteSessionById(sessionId)
    val afterDelete = sessionDao.getAllSessionsWithImages().first()
    assertEquals(0, afterDelete.size)

    db.close()
  }

  @Test
  fun test13_folderNameSanitization() {
    assertEquals("Wallpapers_4K", MediaSaver.sanitizeFolderName("Wallpapers 4K"))
    assertEquals("My_Cool_Gallery", MediaSaver.sanitizeFolderName("My / Cool : Gallery?"))
    assertEquals("Downloads", MediaSaver.sanitizeFolderName("   "))
    val longTitle = "A".repeat(120)
    val sanitizedLong = MediaSaver.sanitizeFolderName(longTitle)
    assertTrue(sanitizedLong.length <= 60)
  }

  @Test
  fun test14_settingsDefaults() {
    val defaults = AppSettings()
    assertEquals(100, defaults.minSizeKb)
    assertEquals(300, defaults.maxSizeKb)
    assertEquals(400, defaults.minDimensionPx)
    assertEquals(5, defaults.maxPageDepth)
    assertEquals(4, defaults.concurrency)
    assertFalse(defaults.wifiOnly)
  }

  @Test
  fun test15_fileSizeFormatting() {
    assertEquals("0 B", formatFileSize(0L))
    assertEquals("500 B", formatFileSize(500L))
    assertEquals("100.0 KB", formatFileSize(100L * 1024))
    assertEquals("295.5 KB", formatFileSize((295.5 * 1024).toLong()))
    assertEquals("1.5 MB", formatFileSize((1.5 * 1024 * 1024).toLong()))
    assertEquals("1.2 GB", formatFileSize((1.2 * 1024 * 1024 * 1024).toLong()))
  }
}
