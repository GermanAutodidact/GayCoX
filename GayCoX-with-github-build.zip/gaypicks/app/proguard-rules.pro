# GayCoX ProGuard / R8 rules
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-keep class androidx.work.** { *; }
-keep class androidx.room.** { *; }
-keep class com.example.data.** { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.jsoup.**
